﻿<?php
include_once('connect_db.php');
//include_once('config.php');
include_once('PHPMailer/PHPMailerAutoload.php');
if(isset($_POST['recover-submit']) && !empty($_POST)){
 $email=mysql_real_escape_string($_POST['email']);
 $res=mysql_query("SELECT * FROM login WHERE email='$email'");
 $count=mysql_num_rows($res);
 if($count==1){
    $r=mysql_fetch_assoc($res);
    $to=$r['email'];
    $password=$r['password'];
    $subject="Your Recovered Password - MU-BEMMS";

    $message="Please use this password to login " . $password;
    $headers="From : MU-BEMMS";
    if(mail($to, $subject, $message, $headers)){
     $smsg="<font color=white>Your password has been sent to your email</font>";
    }else{
     $fmsg1="<font color=red>Failed to recover your password, try again!</font>";
    }
   }else{
    $fmsg2="<font color=red>Email does not exist in database</font>";
   }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Login Help | MU-BEMMS</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/datepicker3.css" rel="stylesheet">
  <link href="css/styles.css" rel="stylesheet">
</head>
<body>
<!--div class="container">
      <!?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <!?php echo $smsg; ?> </div><!?php } ?>
      <!?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <!?php echo $fmsg; ?> </div><!?php } ?>
        <form id="register-form" role="form" autocomplete="off" class="form" method="post">
    <div class="form-group">
   <div class="input-group">
     <span class="input-group-addon"><i class="glyphicon glyphicon-envelope color-blue"></i></span>
     <input id="email" name="email" placeholder="Email Address" class="form-control"  type="email" /required>
   </div>
    </div>
    <div class="form-group">
   <input name="recover-submit" class="btn btn-lg btn-primary btn-block" value="Reset Password" type="submit">
    </div>

    <input type="hidden" class="hide" name="token" id="token" value="">
  </form>
</div-->
<div class="row">
  <div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
    <h4 align="center">Mzumbe University</h4>
    <div class="login-panel panel panel-default" style="padding: 20px; box-shadow: 1px 12px 30px 0px rgba(0,0,0,0.1);">
      <h5 align="center">Building & Estate Maintenance Management<br>System (MU-BEMMS)</h5>
      <center><img src="image/login_logo.png" height="120px" width="135px"></center>
      <div class="panel-body" style="padding: 5px;" align="center">
        <div style="width: 100%; height: 100%; background-color: #00BFFF;"><?php echo $smsg; ?></div>
        <div style="width: 100%; height: 100%; background-color: #FFE5B4;"><?php echo $fmsg1; echo $fmsg2; ?></div>
        <form method="post" action="forgot-password.php" autocomplete="off" style="margin-top: 3px;">
          <fieldset>
            <div class="form-group">
              <input class="form-control" type="email" name="email" placeholder="Email Address" /required>
            </div>
            <center><input style="width: 100%;" type="submit" name="recover-submit" value="Reset Password" class="btn btn-primary"></center>
          </fieldset>
          <input type="hidden" class="hide" name="token" id="token" value="">
        </form>
      </div>
    </div>
    <center><p><a class="fa fa-arrow-left" style="color: gray; font-weight: bold; font-size: 14px;" href="../index.php">Back to Login</a></p></center>
  </div><!-- /.col-->
</div><!-- /.row-->

</body>
</html>
