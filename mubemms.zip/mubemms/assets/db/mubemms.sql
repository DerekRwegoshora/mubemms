-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 28, 2022 at 06:18 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mubemms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=111004 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `first_name`, `last_name`, `email`, `date`) VALUES
(111001, 'Derek', 'Rwegoshora', 'derekeric98@gmail.com', '2022-07-07 00:11:14'),
(111002, 'George', 'Rento', 'george.rento@mzumbe.ac.tz', '2022-07-07 00:11:14'),
(111003, 'Mary', 'Samaeli', 'mary.samaeli@mzumbe.ac.tz', '2022-07-07 00:12:12');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE IF NOT EXISTS `inventory` (
  `inventory_id` int(10) NOT NULL AUTO_INCREMENT,
  `equipment_name` varchar(25) NOT NULL,
  `category` varchar(25) NOT NULL,
  `description` varchar(100) NOT NULL,
  `company` varchar(25) NOT NULL,
  `supplier` varchar(25) NOT NULL,
  `quantity` int(10) NOT NULL,
  `cost` int(10) NOT NULL,
  `status` enum('Available','Inavailable') NOT NULL,
  `date_supplied` date NOT NULL,
  PRIMARY KEY (`inventory_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`inventory_id`, `equipment_name`, `category`, `description`, `company`, `supplier`, `quantity`, `cost`, `status`, `date_supplied`) VALUES
(1, 'Bulbs', 'Electric', '24 WAT bulbs', 'Tronic', 'Tronic', 99, 2200, 'Available', '2022-07-22'),
(2, 'Door handles', 'Door equipment', 'Door Handles', 'Kenwood', 'MO', 50, 45000, 'Available', '2022-07-22'),
(3, 'Socket', 'Electric', '2 Outlet sockets', 'Tronic', 'Tronic', 120, 7000, 'Available', '2022-07-22');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE IF NOT EXISTS `invoice` (
  `invoice_id` int(10) NOT NULL AUTO_INCREMENT,
  `mreq_id` int(10) NOT NULL,
  `student_regno` varchar(13) NOT NULL,
  `student_name` varchar(25) NOT NULL,
  `program` varchar(50) NOT NULL,
  `inventory_id` int(10) NOT NULL,
  `equipment_name` varchar(25) NOT NULL,
  `quantity` int(10) NOT NULL,
  `unit_cost` int(10) NOT NULL,
  `total_cost` int(10) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`invoice_id`),
  KEY `mreq_id` (`mreq_id`),
  KEY `student_regno` (`student_regno`),
  KEY `inventory_id` (`inventory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Triggers `invoice`
--
DROP TRIGGER IF EXISTS `tarehe`;
DELIMITER //
CREATE TRIGGER `tarehe` AFTER INSERT ON `invoice`
 FOR EACH ROW BEGIN
     SET @date=NOW();
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(10) NOT NULL,
  `number` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `name`, `type`, `number`) VALUES
(1, 'Maria Nyerere', 'Hostel', 1),
(2, 'Maria Nyerere', 'Hostel', 2),
(3, 'Maria Nyerere', 'Hostel', 3),
(4, 'Maria Nyerere', 'Hostel', 4),
(5, 'Maria Nyerere', 'Hostel', 5),
(6, 'Kingo', 'Hostel', 1),
(7, 'Kingo', 'Hostel', 2),
(8, 'Kingo', 'Hostel', 3),
(9, 'Kingo', 'Hostel', 4),
(10, 'Kingo', 'Hostel', 5),
(11, 'Kinjekitile', 'Hostel', 1),
(12, 'Kinjekitile', 'Hostel', 2),
(13, 'Kinjekitile', 'Hostel', 3),
(14, 'Kinjekitile', 'Hostel', 4),
(15, 'Kinjekitile', 'Hostel', 5),
(16, 'Mirambo', 'Hostel', 1),
(17, 'Mirambo', 'Hostel', 2),
(18, 'Mirambo', 'Hostel', 3),
(19, 'Mirambo', 'Hostel', 4),
(20, 'Mirambo', 'Hostel', 5),
(21, 'Ntare', 'Venue', 111),
(22, 'Ntare', 'Venue', 112),
(23, 'Ntare', 'Venue', 113),
(24, 'Ntare', 'Venue', 114),
(25, 'Ntare', 'Venue', 115),
(26, 'Mazengo', 'Venue', 101),
(27, 'Mazengo', 'Venue', 102),
(28, 'Mazengo', 'Venue', 103),
(29, 'Mazengo', 'Venue', 104),
(30, 'Mazengo', 'Venue', 105),
(31, 'Fundikira', 'Venue', 101),
(32, 'Fundikira', 'Venue', 102),
(33, 'Fundikira', 'Venue', 103),
(34, 'Fundikira', 'Venue', 104),
(35, 'Fundikira', 'Venue', 105),
(37, 'Fundikira', 'Venue', 107);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `login_id` int(10) NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) NOT NULL,
  `student_regno` int(10) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `year_of_study` int(1) NOT NULL,
  `start_year` year(4) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL DEFAULT 'mu12345678',
  `type` varchar(7) NOT NULL DEFAULT 'Student',
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`login_id`, `admin_id`, `student_regno`, `first_name`, `last_name`, `year_of_study`, `start_year`, `email`, `username`, `password`, `type`) VALUES
(1, 111001, 0, 'Derek', 'Rwegoshora', 0, 0000, 'derekeric98@gmail.com', 'Derek Rwegoshora', 'mzumbe', 'Admin'),
(2, 111002, 0, 'George', 'Rento', 0, 0000, 'george.rento@mzumbe.ac.tz', 'George Rento', 'mzumbe', 'Admin'),
(3, 111003, 0, 'Mary', 'Samaeli', 0, 0000, 'mary.samaeli@mzumbe.ac.tz', 'Mary Samaeli', 'mzumbe', 'Admin'),
(4, 0, 13200000, 'Vaileth', 'Rite', 3, 2019, 'vaileth.rite19@mustudent.ac.tz', 'Vaileth Rite', 'mu12345678', 'Student'),
(5, 0, 13200001, 'Rachel', 'Nashera', 1, 2021, 'rachel.nashera21@mustudent.ac.tz', 'Rachel Nashera', 'mu12345678', 'Student'),
(6, 0, 13200002, 'Daniel', 'Titus', 2, 2020, 'daniel.titus20@mustudent.ac.tz', 'Daniel Titus', 'mu12345678', 'Student'),
(7, 0, 13200003, 'Pifania', 'Makambala', 1, 2021, 'pifania.makambala21@mustudent.ac.tz', 'Pifania Makambala', 'mu12345678', 'Student'),
(8, 0, 13200004, 'Lisa', 'Jeremy', 2, 2020, 'lisa.jeremy20@mustudent.ac.tz', 'Lisa Jeremy', 'mu12345678', 'Student'),
(9, 0, 13200005, 'Steven', 'Erick', 3, 2019, 'steven.erick19@mustudent.ac.tz', 'Steven Erick', 'mu12345678', 'Student'),
(10, 0, 13200006, 'Sarah', 'Njetiro', 2, 2020, 'sarah.njetiro20@mustudent.ac.tz', 'Sarah Njetiro', 'mu12345678', 'Student'),
(11, 0, 13200007, 'Lamek', 'Kondo', 3, 2019, 'lamek.kondo19@mustudent.ac.tz', 'Lamek Kondo', 'mu12345678', 'Student'),
(12, 0, 13200008, 'Vanessa', 'Motto', 2, 2020, 'vanessa.motto20@mustudent.ac.tz', 'Vanessa Motto', 'mu12345678', 'Student'),
(13, 0, 13200009, 'Natasha', 'Zuhurra', 2, 2020, 'natasha.zuhurra21@mustudent.ac.tz', 'Natasha Zuhurra', 'mu12345678', 'Student'),
(14, 0, 13200010, 'Mariam', 'Bakari', 1, 2021, 'mariam.bakari21@mustudent.ac.tz', 'Mariam Bakari', 'mu12345678', 'Student'),
(15, 0, 13200011, 'Thomas', 'Samuel', 1, 2021, 'thomas.samuel21@mustudent.ac.tz', 'Thomas Samuel', 'mu12345678', 'Student'),
(18, 0, 13200014, 'Susan', 'Richard', 1, 2021, 'susan.richard21@mustudent.ac.tz', 'Susan Richard', 'mu12345678', 'Student');

-- --------------------------------------------------------

--
-- Table structure for table `maintenance_history`
--

CREATE TABLE IF NOT EXISTS `maintenance_history` (
  `history_id` int(10) NOT NULL AUTO_INCREMENT,
  `mreq_id` int(10) NOT NULL,
  `student_regno` varchar(13) NOT NULL,
  `student_name` varchar(25) NOT NULL,
  `program` varchar(25) NOT NULL,
  `location` varchar(50) NOT NULL,
  `inventory_id` int(10) NOT NULL,
  `equipment_name` varchar(25) NOT NULL,
  `quantity_used` int(10) NOT NULL,
  `date_used` varchar(25) NOT NULL,
  PRIMARY KEY (`history_id`),
  KEY `mreq_id` (`mreq_id`),
  KEY `inventory_id` (`inventory_id`),
  KEY `student_regno` (`student_regno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mrequest`
--

CREATE TABLE IF NOT EXISTS `mrequest` (
  `mreq_id` int(10) NOT NULL AUTO_INCREMENT,
  `student_regno` varchar(13) NOT NULL,
  `student_name` varchar(25) NOT NULL,
  `program` varchar(25) NOT NULL,
  `phone` int(10) NOT NULL,
  `description` varchar(100) NOT NULL,
  `location` varchar(50) NOT NULL,
  `inventory_id` int(10) NOT NULL,
  `equipment_name` varchar(25) NOT NULL,
  `equip_type` varchar(25) NOT NULL,
  `quantity` int(10) NOT NULL,
  `status` varchar(25) NOT NULL DEFAULT 'Pending',
  `date` date NOT NULL,
  PRIMARY KEY (`mreq_id`),
  KEY `inventory_id` (`inventory_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Triggers `mrequest`
--
DROP TRIGGER IF EXISTS `taree`;
DELIMITER //
CREATE TRIGGER `taree` AFTER INSERT ON `mrequest`
 FOR EACH ROW BEGIN
SET@date=NOW();
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE IF NOT EXISTS `staff` (
  `staff_id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `staff_role` varchar(25) NOT NULL,
  `postal_address` varchar(25) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`staff_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1116 ;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `first_name`, `last_name`, `staff_role`, `postal_address`, `phone`, `email`, `date`) VALUES
(1111, 'Sam', 'Osoro', 'Carpenter', 'P.O.Box, 53 Kabu', '0789653415', 'sam@mustaff.ac.tz', '2013-11-24 14:18:51'),
(1112, 'Kelvin', 'Mwanjiro', 'Electrician', 'P.O.Box 6, Municipal', '0754987654', 'kevoo@mustaff.ac.tz', '2022-06-11 05:45:09'),
(1114, 'Dean', 'Winchester', 'Electrician', 'P.O.Box 12, Frisco', '0912765522', 'deanwin@mustaff.ac.tz', '2022-07-04 00:38:15'),
(1115, 'Joshua', 'Kiimay', 'Electrical Engineer', 'P.O.Box 112, Mlali', '0744327123', 'joshuakiimay@mustaff.ac.tz', '2022-07-22 19:37:22');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `student_regno` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `program` varchar(25) NOT NULL,
  `year_of_study` int(1) NOT NULL,
  `start_year` year(4) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`student_regno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13200015 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_regno`, `first_name`, `last_name`, `program`, `year_of_study`, `start_year`, `phone`, `email`, `date`) VALUES
(13200000, 'Vaileth', 'Rite', 'BSc ICT-M', 3, 2019, '0654123456', 'vaileth.rite19@mustudent.ac.tz', '2022-07-06 23:27:25'),
(13200001, 'Rachel', 'Nashera', 'DIT', 1, 2021, '0783112113', 'rachel.nashera21@mustudent.ac.tz', '2022-07-06 23:37:34'),
(13200002, 'Daniel', 'Titus', 'BSc MICT-EDU', 2, 2020, '0754123456', 'daniel.titus20@mustudent.ac.tz', '2022-07-06 23:37:34'),
(13200003, 'Pifania', 'Makambala', 'CAS', 1, 2021, '0683678389', 'pifania.makambala21@mustudent.ac.tz', '2022-07-07 00:04:04'),
(13200004, 'Lisa', 'Jeremy', 'DAS', 2, 2020, '0620987654', 'lisa.jeremy20@mustudent.ac.tz', '2022-07-06 23:42:17'),
(13200005, 'Steven', 'Erick', 'BSc BEEM', 3, 2019, '0711999215', 'steven.erick19@mustudent.ac.tz', '2022-07-07 00:00:31'),
(13200006, 'Sarah', 'Njetiro', 'DAS', 2, 2020, '0711999212', 'sarah.njetiro20@mustudent.ac.tz', '2022-07-06 23:54:01'),
(13200007, 'Lamek', 'Kondo', 'BSc AS', 3, 2019, '0711765234', 'lamek.kondo19@mustudent.ac.tz', '2022-07-06 23:54:01'),
(13200008, 'Vanessa', 'Motto', 'BSc ICT-B', 2, 2020, '0654987654', 'vanessa.motto20@mustudent.ac.tz', '2022-07-06 23:49:06'),
(13200009, 'Natasha', 'Zuhurra', 'DIT', 2, 2020, '0683678345', 'natasha.zuhurra20@mustudent.ac.tz', '2022-07-06 23:49:06'),
(13200010, 'Mariam', 'Bakari', 'BSc ITS', 1, 2021, '0754998789', 'mariam.bakari21@mustudent.ac.tz', '2022-07-07 00:00:31'),
(13200011, 'Thomas', 'Samuel', 'CLGM', 1, 2021, '0628456123', 'thomas.samuel21@mustudent.ac.tz', '2022-07-06 23:42:17'),
(13200014, 'Susan', 'Richard', 'BSc BPA', 1, 2021, '0715987654', 'susan.richard21@mustudent.ac.tz', '2022-07-27 09:41:48');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoice`
--
ALTER TABLE `invoice`
  ADD CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`mreq_id`) REFERENCES `mrequest` (`mreq_id`),
  ADD CONSTRAINT `invoice_ibfk_3` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`inventory_id`);

--
-- Constraints for table `maintenance_history`
--
ALTER TABLE `maintenance_history`
  ADD CONSTRAINT `maintenance_history_ibfk_1` FOREIGN KEY (`mreq_id`) REFERENCES `mrequest` (`mreq_id`),
  ADD CONSTRAINT `maintenance_history_ibfk_2` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`inventory_id`);

--
-- Constraints for table `mrequest`
--
ALTER TABLE `mrequest`
  ADD CONSTRAINT `mrequest_ibfk_1` FOREIGN KEY (`inventory_id`) REFERENCES `inventory` (`inventory_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
