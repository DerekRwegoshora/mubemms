<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['admin_id'])){
$id=$_SESSION['admin_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
exit();
}
?>
<!DOCTYPE html>
<html>
<?php include 'includes/header.php'?>
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-tachometer">&nbsp;</em> Dashboard</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
			<div class="row">
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-blue panel-widget border-right">
						<div class="row no-padding"><em class="fa fa-xl fa-wrench color-blue"></em>
							<div class="large"><?php
							$sql=mysql_query("SELECT * FROM mrequest WHERE status='Pending'") or die(mysql_error());
							$num=mysql_num_rows($sql);
							echo $num;
							?></div>
							<div class="text-muted">Number of Task Requests</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-teal panel-widget border-right">
						<div class="row no-padding"><em class="fa fa-xl fa-users color-blue"></em>
							<div class="large"><?php
							$sql=mysql_query("SELECT DISTINCT * FROM student") or die(mysql_error());
							$num=mysql_num_rows($sql);
							echo $num;
							?></div>
							<div class="text-muted">Number of Students</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-orange panel-widget border-right">
						<div class="row no-padding"><em class="fa fa-xl fa-user-secret color-blue"></em>
							<div class="large"><?php
							$sql=mysql_query("SELECT DISTINCT * FROM staff") or die(mysql_error());
							$num=mysql_num_rows($sql);
							echo $num;
							?></div>
							<div class="text-muted">Number of Staff Members</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-red panel-widget ">
						<div class="row no-padding"><em class="fa fa-xl fa-money color-blue"></em>
							<div class="large"><?php
							$sql=mysql_query("SELECT DISTINCT * FROM invoice") or die(mysql_error());
							$num=mysql_num_rows($sql);
							echo $num;
							?></div>
							<div class="text-muted">Number of Student Invoices</div>
						</div>
					</div>
				</div>
			</div><!--/.row-->
		</div>
		<div class="row">
			<div class="col-xs-6 col-md-3">
				<div class="panel panel-default">
					<div class="panel-body easypiechart-panel">
						<h6>Pending Maintenance Tasks</h6>
						<?php
							$sql=mysql_query("SELECT * FROM mrequest WHERE status='Pending'") or die(mysql_error());
							$count=mysql_num_rows($sql);
							$sql2=mysql_query("SELECT * FROM mrequest") or die(mysql_error());
							$count2=mysql_num_rows($sql2);
              $math=($count/$count2)*100;
							$percent=round($math,2);
							?>
						<div class="easypiechart" id="easypiechart-blue" data-percent="<?php echo $percent; ?>" ><span class="percent"><?php echo $percent; ?>%</span></div>
					</div>
				</div>
			</div>
			<div class="col-xs-6 col-md-3">
				<div class="panel panel-default">
					<div class="panel-body easypiechart-panel">
						<h6>Completed Maintenance Tasks</h6>
						<?php
							$sql=mysql_query("SELECT * FROM maintenance_history") or die(mysql_error());
							$num=mysql_num_rows($sql);
							$sql2=mysql_query("SELECT * FROM mrequest") or die(mysql_error());
							$num2=mysql_num_rows($sql2);
              $math=($num/$num2)*100;
							$percent=round($math,2);
							?>
						<div class="easypiechart" id="easypiechart-teal" data-percent="<?php echo $percent; ?>" ><span class="percent"><?php echo $percent; ?>%</span></div>
					</div>
				</div>
			</div>
		</div><!--/.row-->

	</div>	<!--/.main-->

    <?php include 'includes/footer.php'?>

</body>
</html>
