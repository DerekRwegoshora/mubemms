<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['admin_id'])){
$id=$_SESSION['admin_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
exit();
}
if(isset($_SESSION['failure'])){
  $failuremessage="<font color=red>".$_SESSION['failure']."</font>";
}
if (isset($_POST['submit'])){
      //get form data, making sure it is valid
        $id0=$_POST['mreq_id'];
        $equipname=$_POST['equipment'];
        $costs=$_POST['quantity'];
        $statuss=$_POST['status'];
        //
        $sql2=mysql_query("SELECT inventory_id,quantity FROM inventory WHERE equipment_name='$equipname'") or die(mysql_error());
        $row2=mysql_fetch_array($sql2);
        $inventid=$row2['inventory_id'];
        $quant=$row2['quantity'];
        //
        if($quant < $costs){
          $message1="<font color=red>Failed to complete, item quantity available is insufficient!</font>";
        }else{
          $sql=mysql_query("UPDATE mrequest SET status='$statuss', date=NOW() WHERE mreq_id='$id0'") or die(mysql_error());
              if($sql > 0){
                $calcquantity=(($quant)-($costs));
                $test=mysql_query("UPDATE inventory SET quantity='$calcquantity' WHERE inventory_id='$inventid'") or die(mysql_error());
                //to insert into the database tables
                $test2=mysql_query("INSERT INTO maintenance_history(mreq_id,student_regno,student_name,program,location,inventory_id,equipment_name,quantity_used,date_used)
                SELECT mreq_id,student_regno,student_name,program,location,inventory_id,equipment_name,quantity,date FROM mrequest WHERE mreq_id='$id0' AND status='Completed'") or die(mysql_error());
                //
                $before=mysql_query("SELECT inventory_id,quantity FROM inventory WHERE equipment_name='$equipname'") or die(mysql_error());
                $shift=mysql_fetch_array($before);
                $innn=$shift['inventory_id'];
                $quantum=$shift['quantity'];
                if($quantum == 0){
                  mysql_query("UPDATE inventory SET status='Inavailable' WHERE inventory_id='$innn'") or die(mysql_error());
                }//
                  if($test > 0 && $test2 > 0){
                    $message="<font color=white>Status has been updated successfuly</font>";
                    header("location:task-information.php");
                  }else{
                    $message2="<font color=red>Error, status couldn't truly update!</font>";
                  }
                }else{
                  $message3="<font color=red>Error, something is wrong...couldn't update!</font>";
                }
            }
        }
  ?>
<!DOCTYPE html>
<html>
<?php include 'includes/header.php'?>
   <link rel="stylesheet" href="../assets/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
   <link rel="stylesheet" href="../assets/css/table.css">
   <script src="../assets/js/sorttable.js"></script>
   <script src="../assets/js/search.js"></script>
   <style>
      .virgo:empty{
        display: none;
      }
   </style>
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Maintenance Tasks</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12"><?php $quantify=mysql_query("SELECT * FROM mrequest WHERE status='Pending'"); $show=mysql_num_rows($quantify);  ?>
				<h1 class="page-header"><em class="fa fa-wrench">&nbsp;</em> Maintenance Task Requests (<?php echo $show; ?> pending)</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
      <div class="search">
        <div>
          <div>
            <label style="color: grey; font-size: 14px; font-weight: normal; border-color: grey;">Search:&nbsp;</label>
            <input style="height: 38px; width: 200px;" type="text" id="myInput" onkeyup="myFunction('example1')" />
          </div>
        </div>
      </div>
			<div class="example1">
       <div class="virgo" align="center" style="width: 100%; height: 25px; background-color: #00BFFF;"><?php echo $message; ?></div>
        <div class="virgo" align="center" style="width: 100%; height: 25px; background-color: #FFE5B4;"><?php echo $message1; echo $message2; echo $message3; echo $failuremessage; ?></div>
            <?php // connect to the database
                include_once('/../assets/connect_db.php');
                // get results from database
                $result = mysql_query("SELECT * FROM mrequest WHERE status='Pending' ORDER BY date DESC")or die(mysql_error());
                // display data in table
			echo '<table id="example1" class="table table-hover">';
            echo '<tr class="theader"><th class="border-top-0">Request Form No.</th>
            <th class="border-top-0">Student ID</th>
            <th class="border-top-0">Student Name</th>
			      <th class="border-top-0">Program</th>
            <th class="border-top-0">Contact</th>
			      <th class="border-top-0">Task Status</th>
            <th class="border-top-0">Date Submitted</th>
            <th class="sorttable_nosort" id="invisible">Action</th></tr>';
            if(mysql_num_rows($result) < 1){
              ?><tr><td colspan="8" align="center">No data available in table</td></tr><?php
            }else{
            while($row=mysql_fetch_array($result)) {
                echo "<tr>";
                echo '<td>' . $row['mreq_id'] . '</td>';
                echo '<td>' . $row['student_regno'] . '</td>';
                echo '<td>' . $row['student_name'] . '</td>';
        				echo '<td>' . $row['program'] . '</td>';
        				echo '<td>' . $row['phone'] . '</td>'; ?>
                <td>
                 <form action="<?php $_PHP_SELF ?>" method="post">
      						<input type="hidden" name="mreq_id" value="<?php echo $row['mreq_id']; ?>" />
                  <input type="hidden" name="equipment" value="<?php echo $row['equipment_name']; ?>" />
                  <input type="hidden" name="quantity" value="<?php echo $row['quantity']; ?>" />
      						<select name="status" id="status" /required>
      							<option value="<?php $row['status']; ?>" selected><?php echo $row['status']; ?></option>
      							<?php if($row['status']!='Pending'){
      						?><option value="Pending">Pending</option><?php
      							}else{
      						?><option value="Completed">Completed</option><?php
      							} ?>
      						</select>
      					 <input class="btn btn-primary" name="submit" type="submit" value="Save" />
      					</form>
      				</td>
        		<?php echo '<td>' . $row['date'] . '</td>'; ?>
                                                <td>
													<ul class="pull-right panel-settings" style="border:none">
														<li class="dropdown"><a class="pull-right dropdown-toggle" data-toggle="dropdown" href="#">
															<em class="fa fa-cogs"></em>
														</a>
															<ul class="dropdown-menu dropdown-menu-right">
																<li>
																	<ul class="dropdown-settings">
																		<li><a href="pdf/create_invoice.php?mreq_id=<?php echo $row['mreq_id']; ?>">
																			<em class="fa fa-plus"></em> generate invoice
																		</a></li>
                                      									<li class="divider"></li>
																		<li><a href="task-details.php?mreq_id=<?php echo $row['mreq_id']; ?>">
																			<em class="fa fa-eye"></em> details
																		</a></li>
                                                                        <li class="divider"></li>
                                                                        <li><a href="pdf/request.php?mreq_id=<?php echo $row['mreq_id']; ?>">
																			<em class="fa fa-download"></em> download
																		</a></li>
                                                                        <li class="divider"></li>
                                                                        <li Onclick="return confirmation()"><a href="delete-task.php?mreq_id=<?php echo $row['mreq_id']; ?>">
																			<em class="fa fa-trash"></em> delete
																			<script>
																				function confirmation() {
																				var result = confirm("Are you sure?");
																				if (result==true) {
																				return true;
																				} else {
																				return false;
																				}
																			}
																		</script>
																		</a></li>
																	</ul>
																</li>
															</ul>
														</li>
													</ul>
												</td>
											</tr>
                      <?php
                      }
                    } ?>
                  </table>
                </div><!--/.row-->
          		</div>
          	</div>	<!--/.main-->

    <?php include 'includes/footer.php'?>

</body>
</html>
