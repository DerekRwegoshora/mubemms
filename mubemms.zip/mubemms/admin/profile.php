<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['admin_id'])){
$id=$_SESSION['admin_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
exit();
}
// get results from admin table in database
$result=mysql_query("SELECT * FROM admin WHERE admin_id='$id'") or die(mysql_error());
$row=mysql_fetch_array($result);
$a_id=$row['admin_id'];
$fname=$row['first_name'];
$lname=$row['last_name'];
$email=$row['email'];
// get results from login table in database
$result2=mysql_query("SELECT username,password FROM login WHERE admin_id='$id'") or die(mysql_error());
$row2=mysql_fetch_array($result2);
$uname=$row2['username'];
$pass=$row2['password'];
?>
<!DOCTYPE html>
<html>
<?php include 'includes/header.php'?>
   <link rel="stylesheet" href="../assets/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Account</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-user">&nbsp;</em> My Profile</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
		<div class="panel-body">
						<div class="col-md-12">
							<form role="form">
								<div class="form-group col-md-12">
									<label>Admin ID</label>
									<input class="form-control" type="text" value="<?php echo 'SSN/'.$a_id; ?>" readonly/>
								</div>
								<div class="form-group col-md-12">
									<label>First Name</label>
									<input class="form-control" type="text" value="<?php echo $fname; ?>" readonly/>
								</div>
								<div class="form-group col-md-12">
									<label>Last Name</label>
									<input class="form-control" type="text" value="<?php echo $lname; ?>" readonly/>
								</div>
								<div class="form-group col-md-12">
									<label>Email</label>
									<input class="form-control" type="text" value="<?php echo $email; ?>" readonly/>
								</div>
								<div class="form-group col-md-12">
								<div class="form-group col-md-8">
								<div class="form-group col-md-12">
									<label>Username</label>
									<input class="form-control" type="text" value="<?php echo $uname; ?>" readonly/>
								</div>
								<div class="form-group col-md-12">
									<label>Password</label>
									<input class="form-control" type="password" value="<?php echo $pass; ?>" readonly/>
								</div>
								</div>
								</div>
							</form>
						</div>
					</div>
		</div>
	</div>	<!--/.main-->

    <?php include 'includes/footer.php'?>
   <!-- DataTables  & Plugins -->
   <script src="../assets/tables/datatables/jquery.dataTables.min.js"></script>
   <script src="../assets/tables/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script>
      $(function () {
         $("#example1").DataTable();
      });
   </script>

</body>
</html>
