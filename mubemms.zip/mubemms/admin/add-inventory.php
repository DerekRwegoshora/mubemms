<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['admin_id'])){
$id=$_SESSION['admin_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
exit();
}
if(isset($_POST['submit'])){
	$ename=$_POST['equipment_name'];
	$cat=$_POST['category'];
	$des=$_POST['description'];
	$com=$_POST['company'];
	$sup=$_POST['supplier'];
	$qua=$_POST['quantity'];
	$cost=$_POST['cost'];
	$sta="Available";
	$query=mysql_query("SELECT * FROM inventory WHERE equipment_name='$ename' AND category='$cat'")or die(mysql_error());
	 $result=mysql_num_rows($query);
	if($result>0){
		$message1="<font color=red>The item entered, already exists!</font>";
		 }else{
	$sql=mysql_query("INSERT INTO inventory(equipment_name,category,description,company,supplier,quantity,cost,status,date_supplied)
	VALUES('$ename','$cat','$des','$com','$sup','$qua','$cost','$sta',NOW())") or die(mysql_error());
	if($sql > 0) {
		$message2="<font color=white>Inventory item has been added successfully</font>";
	}else{
	$message="<font color=red>Failed to add inventory item, please try again!</font>";
	}
  }
}
?>
<!DOCTYPE html>
<html>
<head>
<?php include 'includes/header.php'?>
<script>
function validateForm()
{

//for alphabet characters only
var str=document.form1.equipment_name.value;
var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//comparing user input with the characters one by one
for(i=0;i<str.length;i++)
{
//charAt(i) returns the position of character at specific index(i)
//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
if(valid.indexOf(str.charAt(i))==-1)
{
alert("Item Name Cannot Contain Numerical Values");
document.form1.equipment_name.value="";
document.form1.equipment_name.focus();
return false;
}}

if(document.form1.equipment_name.value=="")
{
alert("Equipment Name Field is Empty");
return false;
}

//for alphabet characters only
var str=document.form1.category.value;
var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//comparing user input with the characters one by one
for(i=0;i<str.length;i++)
{
//charAt(i) returns the position of character at specific index(i)
//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
if(valid.indexOf(str.charAt(i))==-1)
{
alert("Category Cannot Contain Numerical Values");
document.form1.category.value="";
document.form1.category.focus();
return false;
}}


if(document.form1.category.value=="")
{
alert("Category Field is Empty");
return false;
}

//for alphabet characters only
var str=document.form1.quantity.value;
var valid="0123456789";
//comparing user input with the characters one by one
for(i=0;i<str.length;i++)
{
//charAt(i) returns the position of character at specific index(i)
//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
if(valid.indexOf(str.charAt(i))==-1)
{
alert("Quantity Cannot Contain Letters");
document.form1.quantity.value="";
document.form1.quantity.focus();
return false;
}}


if(document.form1.quantity.value=="")
{
alert("Quantity Field is Empty");
return false;
}

//for alphabet characters only
var str=document.form1.cost.value;
var valid="0123456789";
//comparing user input with the characters one by one
for(i=0;i<str.length;i++)
{
//charAt(i) returns the position of character at specific index(i)
//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
if(valid.indexOf(str.charAt(i))==-1)
{
alert("Unit Cost Cannot Contain Letters");
document.form1.cost.value="";
document.form1.cost.focus();
return false;
}}


if(document.form1.cost.value=="")
{
alert("Cost Field is Empty");
return false;
}

}

</script>
</head>
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Item Inventory</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-file-text">&nbsp;</em> Add Item</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
		    <div class="panel-body">
						<div class="col-md-12">
						<div align="center" style="width: 100%; height: 100%; background-color: #00BFFF;"><?php echo $message2; ?></div>
						<div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;"><?php echo $message;
						echo $message1; ?></div>
							<form name="form1" onsubmit="return validateForm(this);" action="add-inventory.php" method="post" style="margin-top: 3px;">
								<div class="form-group col-md-12">
									<label>Item Name</label>
									<input class="form-control" name="equipment_name" type="text" placeholder="Example: Bulbs" required id="equipment_name" maxlength="12"/>
								</div>
                				<div class="form-group col-md-12">
									<label>Category</label>
									<input class="form-control"  name="category" type="text" placeholder="Example: Electric" required id="category" maxlength="12"/>
								</div>
								<div class="form-group col-md-12">
									<label>Description</label>
									<input class="form-control" name="description" type="text" placeholder="Example: 6 pane window" required id="description" maxlength="15"/>
								</div>
								<div class="form-group col-md-12">
									<label>Company</label>
									<input class="form-control" name="company" type="text" placeholder="Example: Tronic"  required id="company" maxlength="12"/>
								</div>
                				<div class="form-group col-md-12">
									<label>Supplier</label>
									<input class="form-control" name="supplier" type="text" placeholder="Example: Kirikuu" required id="supplier" maxlength="12"/>
								</div>
								<div class="form-group col-md-12">
									<label>Quantity</label>
									<input class="form-control" name="quantity" type="number" placeholder="Example: 100" required id="quantity" maxlength="6"/>
								</div>
								<div class="form-group col-md-12">
								<div class="form-group col-md-12">
									<label>Unit Cost</label>
									<input class="form-control" name="cost" type="number" placeholder="Example: 2500" required id="cost" maxlength="9"/>
								</div>
								</div>
								<div class="form-group col-md-12">
									<a href="inventory.php" class="btn btn-primary" >Cancel</a>
                  <input class="btn btn-primary" name="submit" type="submit" value="Submit"/>
								</div>
              </form>
						</div>
			   </div>
			 </div>
			</div><!--/.main-->

    <?php include 'includes/footer.php'?>
   <!-- DataTables  & Plugins -->
   <script src="../assets/tables/datatables/jquery.dataTables.min.js"></script>
   <script src="../assets/tables/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script>
      $(function () {
         $("#example1").DataTable();
      });
   </script>

</body>
</html>
