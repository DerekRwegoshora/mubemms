<?php
session_start();
function renderForm($id0, $firstname, $lastname, $staffrole, $paddress, $contact, $email0, $error){
	if(isset($_SESSION['admin_id'])){
		$id=$_SESSION['admin_id'];
		$user=$_SESSION['username'];
	}else{
		header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
		exit();
		}
?>
<!DOCTYPE html>
<html>
<head>
<?php include 'includes/header.php'?>
   <link rel="stylesheet" href="../assets/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
	 <script>
 function validateForm()
 {

 //for alphabet characters only
 var str=document.form1.first_name.value;
 	var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
 	//comparing user input with the characters one by one
 	for(i=0;i<str.length;i++)
 	{
 	//charAt(i) returns the position of character at specific index(i)
 	//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
 	if(valid.indexOf(str.charAt(i))==-1)
 	{
 	alert("First Name Cannot Contain Numerical Values");
 	document.form1.first_name.value="";
 	document.form1.first_name.focus();
 	return false;
 	}}

 if(document.form1.first_name.value=="")
 {
 alert("First Name Field is Empty");
 return false;
 }

 //for alphabet characters only
 var str=document.form1.last_name.value;
 	var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
 	//comparing user input with the characters one by one
 	for(i=0;i<str.length;i++)
 	{
 	//charAt(i) returns the position of character at specific index(i)
 	//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
 	if(valid.indexOf(str.charAt(i))==-1)
 	{
 	alert("Last Name Cannot Contain Numerical Values");
 	document.form1.last_name.value="";
 	document.form1.last_name.focus();
 	return false;
 	}}


 if(document.form1.last_name.value=="")
 {
 alert("Last Name Field is Empty");
 return false;
 }

 //for alphabet characters only
 var str=document.form1.phone.value;
  var valid="0123456789";
  //comparing user input with the characters one by one
  for(i=0;i<str.length;i++)
  {
  //charAt(i) returns the position of character at specific index(i)
  //indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
  if(valid.indexOf(str.charAt(i))==-1)
  {
  alert("Contact Cannot Contain Letters");
  document.form1.phone.value="";
  document.form1.phone.focus();
  return false;
  }}


 if(document.form1.phone.value=="")
 {
 alert("Last Name Field is Empty");
 return false;
 }

 }

 </script>
</head>
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Staff</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-user-plus">&nbsp;</em> Update Staff Member</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
		    <div class="panel-body">
					<div class="col-md-12">
					 <div align="center" style="width: 100%; height: 100%; background-color: #00BFFF;"><?php echo $message2; ?></div>
						<div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;"><?php echo $message1; ?></div>
						 <?php if ($error!=''){ echo '<div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;">'.$error.'</div>';} ?>
							<form action="update-staff.php" method="post" name="form1" onsubmit="return validateForm(this);" style="margin-top: 3px;">
								<input type="hidden" name="staff_id" value="<?php echo $id0; ?>"/>
								<div class="form-group col-md-12">
									<label>First Name</label>
									<input class="form-control" name="first_name" type="text" value="<?php echo $firstname; ?>" id="first_name" />
								</div>
                				<div class="form-group col-md-12">
									<label>Last Name</label>
									<input class="form-control" name="last_name" type="text" id="last_name" value="<?php echo $lastname; ?>" />
								</div>
								<div class="form-group col-md-12">
									<label>Staff Role</label>
									<input class="form-control" name="staff_role" type="text" id="staff_role" value="<?php echo $staffrole; ?>" />
								</div>
								<div class="form-group col-md-12">
									<label>Address</label>
									<input class="form-control" name="postal_address" type="text" id="postal_address" value="<?php echo $paddress; ?>" />
								</div>
                				<div class="form-group col-md-12">
									<label>Contact</label>
									<input class="form-control" name="phone" type="text" id="phone" value="<?php echo $contact; ?>" minlength="10" maxlength="10" title="Please enter 10 numbers" />
								</div>
								<div class="form-group col-md-12">
									<label>Email</label>
									<input class="form-control" name="email" type="email" id="email" value="<?php echo $email0; ?>" />
								</div>
								<div class="form-group col-md-12">
									<a href="staff.php" class="btn btn-primary" >Cancel</a>
                  <input class="btn btn-primary" name="submit" type="submit" value="Update"/>
								</div>
              </form>
						</div>
			   </div>
			</div>
		</div>	<!--/.main-->

    <?php include 'includes/footer.php'?>
   <!-- DataTables  & Plugins -->
   <script src="../assets/tables/datatables/jquery.dataTables.min.js"></script>
   <script src="../assets/tables/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script>
      $(function () {
         $("#example1").DataTable();
      });
   </script>

</body>
</html>
<?php
  }
  //create the connection
  include_once('/../assets/connect_db.php');

  if (isset($_POST['submit'])){
    // confirm that the 'id' value is a valid integer before getting the form data
    if (is_numeric($_POST['staff_id'])){
      // get form data, making sure it is valid
        $id0=$_POST['staff_id'];
        $fname=$_POST['first_name'];
		$lname=$_POST['last_name'];
		$staffrle=$_POST['staff_role'];
		$postal=$_POST['postal_address'];
		$phone=$_POST['phone'];
		$email=$_POST['email'];

        // check that firstname/lastname fields are both filled in
        if ($fname=='' || $lname=='' || $staffrle=='' || $postal=='' || $phone=='' || $email==''){
          $error="<font color=red>Please fill in all required fields!</font>";
          renderForm($id0, $firstname, $lastname, $staffrole, $paddress, $contact, $email0, $error);
        }else{
			$query=mysql_query("UPDATE staff SET first_name='$fname', last_name='$lname', staff_role='$staffrle',
			postal_address='$postal',phone='$phone',email='$email' WHERE staff_id='$id0'") or die(mysql_error());
			if($query>0) {
				$message2="<font color=white>Staff member has been updated successfully</font>";
				// once saved, redirect back to the view page
				header("location:staff.php");
			}else{
			$message1="<font color=red>Failed to update staff member, please try again!</font>";
			}
        }
      }else{
        echo "Varr Numerical Error!";
      }
    }else{
    // if the form hasn't been submitted, get the data from the db and display the form
    // get the 'id' value from the URL (if it exists), making sure that it is valid (checking that it is numeric/larger than 0)
    if (isset($_GET['staff_id']) && is_numeric($_GET['staff_id']) && $_GET['staff_id'] > 0){
		$id0=mysql_real_escape_string($_GET['staff_id']);

		//select all data that relates to it...
		$sql=mysql_query("SELECT * FROM staff WHERE staff_id='$id0'") or die(mysql_error());
		$row=mysql_fetch_array($sql);
		if($row>0){
			$firstname=$row['first_name'];
			$lastname=$row['last_name'];
			$staffrole=$row['staff_role'];
			$paddress=$row['postal_address'];
			$contact=$row['phone'];
			$email0=$row['email'];
			renderForm($id0, $firstname, $lastname, $staffrole, $paddress, $contact, $email0, '');
      }else{
        echo "No results!";
      }
    }else{
    // if the 'id' in the URL isn't valid, or if there is no 'id' value, display an error
      echo "Error!";
    }
}
?>
