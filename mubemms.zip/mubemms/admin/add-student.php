<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['admin_id'])){
$id=$_SESSION['admin_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
exit();
}
if(isset($_POST['submit'])){
	$ftname=$_POST['firstname'];
	$ltname=$_POST['lastname'];
	$progamme=$_POST['program'];
	$yearofstudy=$_POST['year_of_study'];
	$startyear=$_POST['start_year'];
	$phonez=$_POST['phonez'];
	$emailz=strtolower($ftname.'.'.$ltname.substr($startyear, -2).'@mustudent.ac.tz');
	$username=$ftname.' '.$ltname;
	$pas='mu12345678';
	$type='Student';
	$query=mysql_query("SELECT * FROM student WHERE first_name='$ftname' AND last_name='$ltname' AND program='$progamme' AND email='$emailz'")or die(mysql_error());
	 $result=mysql_num_rows($query);
	if($result > 0){
		$message1="<font color=red>The item entered, already exists!</font>";
		 }else{
	$sql=mysql_query("INSERT INTO student(first_name,last_name,program,year_of_study,start_year,phone,email)
	VALUES('$ftname','$ltname','$progamme','$yearofstudy','$startyear','$phonez','$emailz')");

	$test=mysql_query("SELECT student_regno FROM student WHERE email='$emailz'")or die(mysql_error());
	$fetcher=mysql_fetch_array($test);
	$stuid=$fetcher['student_regno'];

	if($sql > 0 && $test > 0){
		$sql2=mysql_query("INSERT INTO login(student_regno,first_name,last_name,year_of_study,start_year,email,username,password,type)
		VALUES('$stuid','$ftname','$ltname','$yearofstudy','$startyear','$emailz','$username','$pas','$type')");

		if($sql2 > 0) {
			$message2="<font color=white>Student has been added successfully</font>";
		}else{
		$message="<font color=red>Failed to add student, please try again!</font>";
		}
	 }
  }
}
?>
<!DOCTYPE html>
<html>
<?php include 'includes/header.php'?>
	 <script>
 function validateForm()
 {

 //for alphabet characters only
 var str=document.form1.firstname.value;
 	var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
 	//comparing user input with the characters one by one
 	for(i=0;i<str.length;i++)
 	{
 	//charAt(i) returns the position of character at specific index(i)
 	//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
 	if(valid.indexOf(str.charAt(i))==-1)
 	{
 	alert("First Name Cannot Contain Numerical Values");
 	document.form1.firstname.value="";
 	document.form1.firstname.focus();
 	return false;
 	}}

 if(document.form1.firstname.value=="")
 {
 alert("First Name Field is Empty");
 return false;
 }

 //for alphabet characters only
 var str=document.form1.lastname.value;
 	var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
 	//comparing user input with the characters one by one
 	for(i=0;i<str.length;i++)
 	{
 	//charAt(i) returns the position of character at specific index(i)
 	//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
 	if(valid.indexOf(str.charAt(i))==-1)
 	{
 	alert("Last Name Cannot Contain Numerical Values");
 	document.form1.lastname.value="";
 	document.form1.lastname.focus();
 	return false;
 	}}


 if(document.form1.lastname.value=="")
 {
 alert("Last Name Field is Empty");
 return false;
 }

 //for alphabet characters only
 var str=document.form1.phonez.value;
  var valid="0123456789";
  //comparing user input with the characters one by one
  for(i=0;i<str.length;i++)
  {
  //charAt(i) returns the position of character at specific index(i)
  //indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
  if(valid.indexOf(str.charAt(i))==-1)
  {
  alert("Contact Cannot Contain Letters");
  document.form1.phonez.value="";
  document.form1.phonez.focus();
  return false;
  }}


 if(document.form1.phonez.value=="")
 {
 alert("Last Name Field is Empty");
 return false;
 }

 }

 </script>
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Students</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-users">&nbsp;</em> Add Student</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
		    <div class="panel-body">
						<div class="col-md-12">
						<div align="center" style="width: 100%; height: 100%; background-color: #00BFFF;"><?php echo $message2; ?></div>
						<div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;"><?php echo $message;
						echo $message1; ?></div>
							<form name="form1" onsubmit="return validateForm(this);" action="add-student.php" method="post" style="margin-top: 3px;">
								<div class="form-group col-md-12">
									<label>First Name</label>
									<input class="form-control" name="firstname" type="text" id="firstname" placeholder="Example: Susan" /required>
								</div>
                				<div class="form-group col-md-12">
									<label>Last Name</label>
									<input class="form-control" name="lastname" type="text" id="lastname" placeholder="Example: Roberts" /required>
								</div>
								<div class="form-group col-md-12">
									<label>Program</label>
									<input class="form-control" name="program" type="text" id="program" placeholder="Example: BSc BPA" /required>
								</div>
								<div class="form-group col-md-12">
									<label>Year of Study</label>
									<input class="form-control" name="year_of_study" type="text" id="year_of_study" minlength="1" maxlength="1" placeholder="Example: 1" /required>
								</div>
								<div class="form-group col-md-12">
									<label>Start Year</label>
									<input class="form-control" name="start_year" type="text" id="start_year" minlength="4" maxlength="4" placeholder="Example: 2022" /required>
								</div>
                <div class="form-group col-md-12">
									<label>Contact</label>
									<input class="form-control" name="phonez" type="text" id="phonez" minlength="10" maxlength="10" placeholder="Example: 0712345678" /required>
								</div>
								<div class="form-group col-md-12">
									<a href="student.php" class="btn btn-primary" >Cancel</a>
                  <input class="btn btn-primary" name="submit" type="submit" value="Submit"/>
								</div>
              </form>
						</div>
			   </div>
			 </div>
			</div><!--/.main-->

    <?php include 'includes/footer.php'?>
   <!-- DataTables  & Plugins -->
   <script src="../assets/tables/datatables/jquery.dataTables.min.js"></script>
   <script src="../assets/tables/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script>
      $(function () {
         $("#example1").DataTable();
      });
   </script>

</body>
</html>
