<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['admin_id'])){
$id=$_SESSION['admin_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
exit();
}
?>
<!DOCTYPE html>
<html>
<?php include 'includes/header.php'?>
   <link rel="stylesheet" href="../assets/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
   <link rel="stylesheet" href="../assets/css/table.css">
   <script src="../assets/js/sorttable.js"></script>
   <script src="../assets/js/search.js"></script>
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Students</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12"><?php $quantify=mysql_query("SELECT * FROM student"); $show=mysql_num_rows($quantify);  ?>
				<h1 class="page-header"><em class="fa fa-users">&nbsp;</em> Student Roster (<?php echo $show; ?> students)</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
      <div class="search">
        <div>
          <div>
            <label style="color: grey; font-size: 14px; font-weight: normal; border-color: grey;">Search:&nbsp;</label>
            <input style="height: 38px; width: 200px;" type="text" id="myInput" onkeyup="myFunction('example1')" />
          </div>
        </div>
      </div>
			<div class="example1">
			<?php // connect to the database
        		include_once('/../assets/connect_db.php');
            // get results from database
       		$result = mysql_query("SELECT * FROM student")or die(mysql_error());
				// display data in table
				echo '<table id="example1" class="table table-hover">';
                echo '<tr class="theader"><th class="border-top-0">Student ID</th>
                <th class="border-top-0">First Name</th>
                <th class="border-top-0">Last Name</th>
                <th class="border-top-0">Program</th>
                <th class="border-top-0">Contact</th>
                <th class="border-top-0">Email</th>
                <th class="border-top-0">Added</th>
                <th class="sorttable_nosort" id="invisible">Action</th></tr>';
                if(mysql_num_rows($result) < 1){
                  ?><tr><td colspan="8" align="center">No data available in table</td></tr><?php
                }else{
                while($row = mysql_fetch_array( $result )) {
        					echo '<tr>';
                  $startyear=substr($row['start_year'], -2);
                  $superid=$row['student_regno'].'/T.'.$startyear;
                  echo '<td>' . $superid . '</td>';
        					echo '<td>' . $row['first_name'] . '</td>';
        					echo '<td>' . $row['last_name'] . '</td>';
                  $programm=$row['program']." ".$row['year_of_study'];
                  echo '<td>' . $programm . '</td>';
        					echo '<td>' . $row['phone'] . '</td>';
        					echo '<td>' . $row['email'] . '</td>';
        					echo '<td>' . $row['date'] . '</td>'; ?>
												<td>
													<ul class="pull-right panel-settings" style="border:none">
														<li class="dropdown"><a class="pull-right dropdown-toggle" data-toggle="dropdown" href="#">
															<em class="fa fa-cogs"></em>
														</a>
															<ul class="dropdown-menu dropdown-menu-right">
																<li>
																	<ul class="dropdown-settings">
																		<li><a href="update-student.php?student_regno=<?php echo $row['student_regno']; ?>">
																			<em class="fa fa-edit"></em> edit
																		</a></li>
																		<li class="divider"></li>
																		<li Onclick="return confirmation()"><a href="delete-student.php?student_regno=<?php echo $row['student_regno']; ?>">
																			<em class="fa fa-trash"></em> delete
																			<script>
																				function confirmation() {
																				var result = confirm("Are you sure?");
																				if (result==true) {
																				return true;
																				} else {
																				return false;
																				}
																			}
																		</script>
																		</a></li>
																	</ul>
																</li>
															</ul>
														</li>
													</ul>
												</td>
                      </tr>
                    <?php
		                }
                  } ?>
                </table>
			</div><!--/.row-->
		</div>
	</div>	<!--/.main-->

    <?php include 'includes/footer.php'?>

</body>
</html>
