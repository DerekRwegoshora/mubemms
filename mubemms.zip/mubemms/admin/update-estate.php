<?php
session_start();
function renderForm($id0, $namez, $type, $numberz, $error){
	if(isset($_SESSION['admin_id'])){
		$id=$_SESSION['admin_id'];
		$user=$_SESSION['username'];
	}else{
		header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
		exit();
		}
?>
<!DOCTYPE html>
<html>
<head>
<?php include 'includes/header.php'?>
   <link rel="stylesheet" href="../assets/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
	 <script>
 function validateForm()
 {

 //for alphabet characters only
 var str=document.form1.name.value;
 	var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
 	//comparing user input with the characters one by one
 	for(i=0;i<str.length;i++)
 	{
 	//charAt(i) returns the position of character at specific index(i)
 	//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
 	if(valid.indexOf(str.charAt(i))==-1)
 	{
 	alert("Building Name Cannot Contain Numerical Values");
 	document.form1.name.value="";
 	document.form1.name.focus();
 	return false;
 	}}

 if(document.form1.name.value=="")
 {
 alert("Building Name Field is Empty");
 return false;
 }

 //for alphabet characters only
 var str=document.form1.type.value;
 	var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
 	//comparing user input with the characters one by one
 	for(i=0;i<str.length;i++)
 	{
 	//charAt(i) returns the position of character at specific index(i)
 	//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
 	if(valid.indexOf(str.charAt(i))==-1)
 	{
 	alert("Type Cannot Contain Numerical Values");
 	document.form1.type.value="";
 	document.form1.type.focus();
 	return false;
 	}}


 if(document.form1.type.value=="")
 {
 alert("Type Field is Empty");
 return false;
 }

 //for alphabet characters only
 var str=document.form1.number.value;
  var valid="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  //comparing user input with the characters one by one
  for(i=0;i<str.length;i++)
  {
  //charAt(i) returns the position of character at specific index(i)
  //indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
  if(valid.indexOf(str.charAt(i))==-1)
  {
  alert("Room Number/Floor Level Cannot Contain Special Characters");
  document.form1.number.value="";
  document.form1.number.focus();
  return false;
  }}


 if(document.form1.number.value=="")
 {
 alert("Number Field is Empty");
 return false;
 }

 }

 </script>
 </head>
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Buildings & Estates</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-building">&nbsp;</em> Update Building or Estate</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
		    <div class="panel-body">
					<div class="col-md-12">
					 <div align="center" style="width: 100%; height: 100%; background-color: #00BFFF;"><?php echo $message2; ?></div>
						<div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;"><?php echo $message1; ?></div>
						 <?php if ($error!=''){ echo '<div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;">'.$error.'</div>';} ?>
							<form action="update-estate.php" method="post" name="form1" onsubmit="return validateForm(this);" style="margin-top: 3px;">
								<input type="hidden" name="id" value="<?php echo $id0; ?>"/>
								<div class="form-group col-md-12">
									<label>Estate Name</label>
									<input class="form-control" name="name" type="text" value="<?php echo $namez; ?>" required id="name" />
								</div>
								<div class="form-group col-md-12">
									<label>Estate Type</label>
									<input class="form-control" name="type" type="text" value="<?php echo $type; ?>" required id="type"/>
								</div>
								<div class="form-group col-md-12">
									<label>Room Number/Floor Level</label>
									<input class="form-control" name="number" type="text" value="<?php echo $numberz; ?>" required id="number" />
								</div>
								<div class="form-group col-md-12">
									<a href="estate.php" class="btn btn-primary" >Cancel</a>
                  <input class="btn btn-primary" name="submit" type="submit" value="Update"/>
								</div>
              </form>
						</div>
			   </div>
			</div>
		</div>	<!--/.main-->

    <?php include 'includes/footer.php'?>
   <!-- DataTables  & Plugins -->
   <script src="../assets/tables/datatables/jquery.dataTables.min.js"></script>
   <script src="../assets/tables/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script>
      $(function () {
         $("#example1").DataTable();
      });
   </script>

</body>
</html>
<?php
  }
  //create the connection
  include_once('/../assets/connect_db.php');

  if (isset($_POST['submit'])){
    // confirm that the 'id' value is a valid integer before getting the form data
    if (is_numeric($_POST['id'])){
      // get form data, making sure it is valid
        $id0=$_POST['id'];
				$name=$_POST['name'];
				$typee=$_POST['type'];
				$nums=$_POST['number'];

        // check that firstname/lastname fields are both filled in
        if ($name=='' || $typee=='' || $nums==''){
          $error="<font color=red>Please fill in all required fields!</font>";
          renderForm($id0, $namez, $type, $numberz, $error);
        }else{
			$query=mysql_query("UPDATE location SET name='$name', type='$typee', number='$nums' WHERE id='$id0'") or die(mysql_error());
			if($query>0) {
				$message2="<font color=white>Building/Estate has been updated successfully</font>";
				// once saved, redirect back to the view page
				header("location:estate.php");
			}else{
			$message1="<font color=red>Failed to update building/estate, please try again!</font>";
			}
        }
      }else{
        echo "Varr Numerical Error!";
      }
    }else{
    // if the form hasn't been submitted, get the data from the db and display the form
    // get the 'id' value from the URL (if it exists), making sure that it is valid (checking that it is numeric/larger than 0)
    if (isset($_GET['id']) && is_numeric($_GET['id']) && $_GET['id'] > 0){
		$id0=mysql_real_escape_string($_GET['id']);

		//select all data that relates to it...
		$sql=mysql_query("SELECT * FROM location WHERE id='$id0'") or die(mysql_error());
		$row=mysql_fetch_array($sql);
		if($row>0){
			$namez=$row['name'];
			$type=$row['type'];
			$numberz=$row['number'];
			renderForm($id0, $namez, $type, $numberz, '');
      }else{
        echo "No results!";
      }
    }else{
    // if the 'id' in the URL isn't valid, or if there is no 'id' value, display an error
      echo "Error!";
    }
}
?>
