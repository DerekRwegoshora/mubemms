<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['admin_id'])){
$id=$_SESSION['admin_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
exit();
}
if(isset($_POST['submit'])){
	$fname=$_POST['first_name'];
	$lname=$_POST['last_name'];
	$staffrole=$_POST['staff_role'];
	$postal=$_POST['postal_address'];
	$phone=$_POST['phone'];
	$email=$_POST['email'];
	$sql1=mysql_query("SELECT * FROM staff WHERE first_name='$fname' AND last_name='$lname' AND email='$email'")or die(mysql_error());
	 $result=mysql_num_rows($sql1);
	if($result>0){
	$message="<font color=red>The username entered, already exists!</font>";
	 }else{
	$sql=mysql_query("INSERT INTO staff(first_name,last_name,staff_role,postal_address,phone,email)
	VALUES('$fname','$lname','$staffrole','$postal','$phone','$email')");
	if($sql>0) {
		$message2="<font color=white>Staff member has been added successfully</font>";
	}else{
	$message1="<font color=red>Failed to add staff member, please try again!</font>";
	}
  }
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include 'includes/header.php'?>
	<script>
function validateForm()
{

//for alphabet characters only
var str=document.form1.first_name.value;
	var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	//comparing user input with the characters one by one
	for(i=0;i<str.length;i++)
	{
	//charAt(i) returns the position of character at specific index(i)
	//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
	if(valid.indexOf(str.charAt(i))==-1)
	{
	alert("First Name Cannot Contain Numerical Values");
	document.form1.first_name.value="";
	document.form1.first_name.focus();
	return false;
	}}

if(document.form1.first_name.value=="")
{
alert("First Name Field is Empty");
return false;
}

//for alphabet characters only
var str=document.form1.last_name.value;
	var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	//comparing user input with the characters one by one
	for(i=0;i<str.length;i++)
	{
	//charAt(i) returns the position of character at specific index(i)
	//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
	if(valid.indexOf(str.charAt(i))==-1)
	{
	alert("Last Name Cannot Contain Numerical Values");
	document.form1.last_name.value="";
	document.form1.last_name.focus();
	return false;
	}}


if(document.form1.last_name.value=="")
{
alert("Last Name Field is Empty");
return false;
}

//for alphabet characters only
var str=document.form1.phone.value;
 var valid="0123456789";
 //comparing user input with the characters one by one
 for(i=0;i<str.length;i++)
 {
 //charAt(i) returns the position of character at specific index(i)
 //indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
 if(valid.indexOf(str.charAt(i))==-1)
 {
 alert("Contact Cannot Contain Letters");
 document.form1.phone.value="";
 document.form1.phone.focus();
 return false;
 }}


if(document.form1.phone.value=="")
{
alert("Last Name Field is Empty");
return false;
}

}

</script>
</head>
   <link rel="stylesheet" href="../assets/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Staff</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-user-secret">&nbsp;</em> Add Staff</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
		    <div class="panel-body">
						<div class="col-md-12">
						<div align="center" style="width: 100%; height: 100%; background-color: #00BFFF;"><?php echo $message2; ?></div>
						<div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;"><?php echo $message;
						echo $message1; ?></div>
							<form name="form1" onsubmit="return validateForm(this);" action="add-staff.php" method="post" style="margin-top: 3px;">
								<div class="form-group col-md-12">
									<label>First Name</label>
									<input class="form-control" name="first_name" type="text" placeholder="Example: Brian" required id="first_name" />
								</div>
                				<div class="form-group col-md-12">
									<label>Last Name</label>
									<input class="form-control" name="last_name" type="text" placeholder="Example: John" required id="last_name" />
								</div>
								<div class="form-group col-md-12">
									<label>Staff Role</label>
									<input class="form-control" name="staff_role" type="text" placeholder="Example: Electrician" required id="staff_role"/>
								</div>
								<div class="form-group col-md-12">
									<label>Address</label>
									<input class="form-control" name="postal_address" type="text" placeholder="Example: P.O.Box 35 Mzumbe" required id="postal_address" />
								</div>
                				<div class="form-group col-md-12">
									<label>Contact</label>
									<input class="form-control" name="phone" type="text" placeholder="Example: 0715987654"  required id="phone" minlength="10" maxlength="10" title="Please enter 10 numbers"/>
								</div>
								<div class="form-group col-md-12">
									<label>Email</label>
									<input class="form-control" name="email" type="email"  placeholder="Example: name@mzumbe.ac.tz" required id="email" />
								</div>
								<div class="form-group col-md-12">
									<a href="staff.php" class="btn btn-primary" >Cancel</a>
                  <input class="btn btn-primary" name="submit" type="submit" value="Submit"/>
								</div>
              </form>
						</div>
			   </div>
			 </div>
			</div><!--/.main-->

    <?php include 'includes/footer.php'?>
   <!-- DataTables  & Plugins -->
   <script src="../assets/tables/datatables/jquery.dataTables.min.js"></script>
   <script src="../assets/tables/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script>
      $(function () {
         $("#example1").DataTable();
      });
   </script>

</body>
</html>
