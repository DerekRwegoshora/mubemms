<?php
	session_start();
	function renderForm($id0, $equipname, $categ, $desc, $comp, $supplier, $quantity, $cost0, $status, $date, $error){
		if(isset($_SESSION['admin_id'])){
			$id=$_SESSION['admin_id'];
			$user=$_SESSION['username'];
		}else{
			header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
			exit();
			}
?>
<!DOCTYPE html>
<html>
<head>
<?php include 'includes/header.php'?>
   <link rel="stylesheet" href="../assets/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
	 <script>
 function validateForm()
 {

 //for alphabet characters only
 var str=document.form1.equipment_name.value;
 	var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
 	//comparing user input with the characters one by one
 	for(i=0;i<str.length;i++)
 	{
 	//charAt(i) returns the position of character at specific index(i)
 	//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
 	if(valid.indexOf(str.charAt(i))==-1)
 	{
 	alert("Item Name Cannot Contain Numerical Values");
 	document.form1.equipment_name.value="";
 	document.form1.equipment_name.focus();
 	return false;
 	}}

 if(document.form1.equipment_name.value=="")
 {
 alert("Equipment Name Field is Empty");
 return false;
 }

 //for alphabet characters only
 var str=document.form1.category.value;
 	var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
 	//comparing user input with the characters one by one
 	for(i=0;i<str.length;i++)
 	{
 	//charAt(i) returns the position of character at specific index(i)
 	//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
 	if(valid.indexOf(str.charAt(i))==-1)
 	{
 	alert("Category Cannot Contain Numerical Values");
 	document.form1.category.value="";
 	document.form1.category.focus();
 	return false;
 	}}


 if(document.form1.category.value=="")
 {
 alert("Category Field is Empty");
 return false;
 }

 //for alphabet characters only
 var str=document.form1.quantity.value;
  var valid="0123456789";
  //comparing user input with the characters one by one
  for(i=0;i<str.length;i++)
  {
  //charAt(i) returns the position of character at specific index(i)
  //indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
  if(valid.indexOf(str.charAt(i))==-1)
  {
  alert("Quantity Cannot Contain Letters");
  document.form1.quantity.value="";
  document.form1.quantity.focus();
  return false;
  }}


 if(document.form1.quantity.value=="")
 {
 alert("Quantity Field is Empty");
 return false;
 }

 //for alphabet characters only
 var str=document.form1.cost.value;
  var valid="0123456789";
  //comparing user input with the characters one by one
  for(i=0;i<str.length;i++)
  {
  //charAt(i) returns the position of character at specific index(i)
  //indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
  if(valid.indexOf(str.charAt(i))==-1)
  {
  alert("Unit Cost Cannot Contain Letters");
  document.form1.cost.value="";
  document.form1.cost.focus();
  return false;
  }}


 if(document.form1.cost.value=="")
 {
 alert("Cost Field is Empty");
 return false;
 }

 }

 </script>
 </head>
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Item Inventory</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-user-plus">&nbsp;</em> Update Item</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
		    <div class="panel-body">
				<div class="col-md-12">
				  <div align="center" style="width: 100%; height: 100%; background-color: #00BFFF;"><?php echo $message2; ?></div>
					 <div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;"><?php echo $message1; ?></div>
					  <?php if ($error!=''){ echo '<div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;">'.$error.'</div>';} ?>
							<form action="update-inventory.php" method="post" name="form1" onsubmit="return validateForm(this);" style="margin-top: 3px;">
							<div class="form-group col-md-12">
									<input type="hidden" name="inventory_id" value="<?php echo $id0; ?>"/>
									<label>Item Name</label>
									<input class="form-control" name="equipment_name" type="text" value="<?php echo $equipname; ?>" id="equipment_name" maxlength="12"/>
								</div>
                				<div class="form-group col-md-12">
									<label>Category</label>
									<input class="form-control"  name="category" type="text" value="<?php echo $categ; ?>" id="category" maxlength="12"/>
								</div>
								<div class="form-group col-md-12">
									<label>Description</label>
									<input class="form-control" name="description" type="text" value="<?php echo $desc; ?>" id="description" maxlength="12"/>
								</div>
								<div class="form-group col-md-12">
									<label>Company</label>
									<input class="form-control" name="company" type="text" value="<?php echo $comp; ?>" id="company" maxlength="12"/>
								</div>
                				<div class="form-group col-md-12">
									<label>Supplier</label>
									<input class="form-control" name="supplier" type="text" value="<?php echo $supplier; ?>" id="supplier" maxlength="12"/>
								</div>
								<div class="form-group col-md-12">
									<label>Quantity</label>
									<input class="form-control" name="quantity" type="number" value="<?php echo $quantity; ?>" id="quantity" maxlength="6"/>
								</div>
								<div class="form-group col-md-12">
								<div class="form-group col-md-12">
									<label>Unit Cost</label>
									<input class="form-control" name="cost" type="number" value="<?php echo $cost0; ?>" id="cost" maxlength="9"/>
								</div>
								<div class="form-group col-md-12">
									<label>Status</label>
										<select name="status" id="status" /required>
											<option value="<?php echo $status ?>" selected><?php echo $status ?></option>
											<?php if($status!='Available'){
										?><option value="Available">Available</option><?php
											}else{
										?><option value="Inavailable">Inavailable</option><?php
											} ?>
										</select>
								</div>
								<div class="form-group col-md-12">
									<label>Date Added</label>
									<input class="form-control" name="date" type="text" placeholder="Date Added" value="<?php echo $date; ?>" id="date" readonly/>
								</div>
								</div>
								<div class="form-group col-md-12">
									<a href="inventory.php" class="btn btn-primary" >Cancel</a>
									<input class="btn btn-primary" name="submit" type="submit" value="Update"/>
								</div>
              </form>
						</div>
			   </div>
			</div>
		</div>	<!--/.main-->

    <?php include 'includes/footer.php'?>
   <!-- DataTables  & Plugins -->
   <script src="../assets/tables/datatables/jquery.dataTables.min.js"></script>
   <script src="../assets/tables/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script>
      $(function () {
         $("#example1").DataTable();
      });
   </script>

</body>
</html>
<?php
  }
  //create the connection
  include_once('/../assets/connect_db.php');

  if (isset($_POST['submit'])){
    // confirm that the 'id' value is a valid integer before getting the form data
    if (is_numeric($_POST['inventory_id'])){
      // get form data, making sure it is valid
        $id0=$_POST['inventory_id'];
        $ename=$_POST['equipment_name'];
        $cat=$_POST['category'];
        $des=$_POST['description'];
		$com=$_POST['company'];
        $sup=$_POST['supplier'];
		$qua=$_POST['quantity'];
		$cost=$_POST['cost'];
		$sta=$_POST['status'];

        // check that firstname/lastname fields are both filled in
        if ($ename=='' || $cat=='' || $des=='' || $com=='' || $sup=='' || $qua=='' || $cost=='' || $sta==''){
          $error="<font color=red>Please fill in all required fields!</font>";
          renderForm($id0, $equipname, $categ, $desc, $comp, $supplier, $quantity, $cost0, $status, $date, $error);
        }else{
			$query=mysql_query("UPDATE inventory SET equipment_name='$ename', category='$cat', description='$des',
			company='$com', supplier='$sup', quantity='$qua', cost='$cost', status='$sta' WHERE inventory_id='$id0'") or die(mysql_error());
			if($query>0) {
				$message2="<font color=white>Inventory item has been updated successfully</font>";
				// once saved, redirect back to the view page
				header("location:inventory.php");
			}else{
			$message1="<font color=red>Failed to update inventory item, please try again!</font>";
			}
        }
      }else{
        echo "Varr Numerical Error!";
      }
    }else{
    // if the form hasn't been submitted, get the data from the db and display the form
    // get the 'id' value from the URL (if it exists), making sure that it is valid (checking that it is numeric/larger than 0)
    if (isset($_GET['inventory_id']) && is_numeric($_GET['inventory_id']) && $_GET['inventory_id'] > 0){
		$id0=mysql_real_escape_string($_GET['inventory_id']);

		//select all data that relates to it...
		$sql=mysql_query("SELECT * FROM inventory WHERE inventory_id='$id0'") or die(mysql_error());
		$row=mysql_fetch_array($sql);
		if($row>0){
			$equipname=$row['equipment_name'];
			$categ=$row['category'];
			$desc=$row['description'];
			$comp=$row['company'];
			$supplier=$row['supplier'];
			$quantity=$row['quantity'];
			$cost0=$row['cost'];
			$status=$row['status'];
			$date=$row['date_supplied'];
			renderForm($id0, $equipname, $categ, $desc, $comp, $supplier, $quantity, $cost0, $status, $date, '');
      }else{
        echo "No results!";
      }
    }else{
    // if the 'id' in the URL isn't valid, or if there is no 'id' value, display an error
      echo "Error!";
    }
}
?>
