<?php
	session_start();
	function renderForm($id0, $mreq_id, $studentreg, $studentnm, $program, $invenid, $equipmentname, $quantity, $icost, $tcost, $date, $error){
		if(isset($_SESSION['admin_id'])){
			$id=$_SESSION['admin_id'];
			$user=$_SESSION['username'];
		}else{
			header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
			exit();
			}
?>
<!DOCTYPE html>
<html>
<head>
<?php include 'includes/header.php'?>
   <link rel="stylesheet" href="../assets/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
	 <script>
 function validateForm()
 {
 //for alphabet characters only
 var str=document.form1.quantity.value;
  var valid="0123456789";
  //comparing user input with the characters one by one
  for(i=0;i<str.length;i++)
  {
  //charAt(i) returns the position of character at specific index(i)
  //indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
  if(valid.indexOf(str.charAt(i))==-1)
  {
  alert("Quantity Cannot Contain Letters");
  document.form1.quantity.value="";
  document.form1.quantity.focus();
  return false;
  }}


 if(document.form1.quantity.value=="")
 {
 alert("Quantity Field is Empty");
 return false;
 }

 }

 </script>
</head>
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Invoice</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-user-plus">&nbsp;</em> Update Invoice</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
		    <div class="panel-body">
				<div class="col-md-12">
					<?php if ($error!=''){ echo '<div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;">'.$error.'</div>';} ?>
							<form action="update-invoice.php" method="post" name="form1" onsubmit="return validateForm(this);">
								<div class="form-group col-md-12">
									<label>Bill No</label>
									<input class="form-control" type="number" name="invoice_id" value="<?php echo $id0; ?>" id="invoice_id" readonly/>
								</div>
								<div class="form-group col-md-12">
									<label>Request Form No.</label>
									<input class="form-control" type="number" name="mreq_id" value="<?php echo $mreq_id; ?>" id="mreq_id" readonly/>
								</div>
								<div class="form-group col-md-12">
									<label>Student ID</label>
									<input class="form-control"  name="student_regno" type="number" value="<?php echo $studentreg; ?>" id="student_regno" readonly/>
								</div>
								<div class="form-group col-md-12">
									<label>Student Name</label>
									<input class="form-control" name="student_name" type="text" value="<?php echo $studentnm; ?>" id="student_name" readonly/>
								</div>
								<div class="form-group col-md-12">
									<label>Program</label>
									<input class="form-control" name="program" type="text" value="<?php echo $program; ?>" id="program" readonly/>
								</div>
								<div class="form-group col-md-12">
									<label>Item No.</label>
									<input class="form-control" name="inventory_id" type="number" value="<?php echo $invenid; ?>" id="inventory_id" readonly/>
								</div>
								<div class="form-group col-md-12">
									<label>Item Name</label>
									<select class="form-control" name="equipment_name" id="equipment_name">
										<option value="<?php echo $equipmentname; ?>" selected><?php echo $equipmentname; ?></option>
										<?php
											$iquery=mysql_query("SELECT equipment_name FROM inventory WHERE status='Available'") or die(mysql_error());
											if($iquery>0){
											while($fetchy=mysql_fetch_array(iquery)){
												$eqname=$fetchy['equipment_name'];
												echo '<option value="'.$eqname.'">'.$eqname.'</option>';
											}
										}else{
											echo '<option value="" disabled selected hidden>No inventory added/Inavailable</option>';
										}
										?>
									</select>
								</div>
								<div class="form-group col-md-12">
									<label>Item Quantity</label>
									<input class="form-control" name="quantity" type="number" value="<?php echo $quantity; ?>" id="quantity" maxlength="6"/>
								</div>
								<div class="form-group col-md-12">
								<div class="form-group col-md-12">
									<label>Unit Cost</label>
									<input class="form-control" name="unit_cost" type="number" value="<?php echo $icost; ?>" id="unit_cost" readonly/>
								</div>
								<div class="form-group col-md-12">
									<label>Total Cost</label>
									<input class="form-control" name="total_cost" type="number" value="<?php echo $tcost; ?>" id="total_cost" readonly/>
								</div>
								<div class="form-group col-md-12">
									<label>Date Issued</label>
									<input class="form-control" name="date" type="text" value="<?php echo $date; ?>" id="date" readonly/>
								</div>
								</div>
								<div class="form-group col-md-12">
									<a href="invoice.php" class="btn btn-primary" >Cancel</a>
									<input class="btn btn-primary" name="submit" type="submit" value="Update"/>
								</div>
              </form>
						</div>
			   </div>
			</div>
		</div>	<!--/.main-->

    <?php include 'includes/footer.php'?>
   <!-- DataTables  & Plugins -->
   <script src="../assets/tables/datatables/jquery.dataTables.min.js"></script>
   <script src="../assets/tables/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script>
      $(function () {
         $("#example1").DataTable();
      });
   </script>

</body>
</html>
<?php
  }
  //create the connection
  include_once('/../assets/connect_db.php');

  if (isset($_POST['submit'])){
    // confirm that the 'id' value is a valid integer before getting the form data
    if (is_numeric($_POST['invoice_id'])){
      // get form data, making sure it is valid
				$eqname=$_POST['equipment_name'];
				$qua=$_POST['quantity'];
				//select...to update
				$query=mysql_query("SELECT inventory_id,cost FROM inventory WHERE equipment_name='$eqname'") or die(mysql_error());
				$fetcher=mysql_fetch_array($query);
				$upinid=$fetcher['inventory_id'];
				$upcost=$fetcher['cost'];
				$totcost=(($qua)*($upcost));
        // check that firstname/lastname fields are both filled in
        if ($qua=='' || $eqname==''){
          $error="<font color=red>Please fill in all required fields!</font>";
          renderForm($id0, $mreq_id, $studentreg, $studentnm, $program, $invenid, $equipmentname, $quantity, $icost, $tcost, $date, $error);
        }else{
			mysql_query("UPDATE invoice SET inventory_id='$upinid', equipment_name='$eqname', quantity='$qua', unit_cost='$upcost', total_cost='$totcost' WHERE invoice_id='$id0'") or die(mysql_error());

          // once saved, redirect back to the view page
          header("location:invoice.php");
        }
      }else{
        echo "Error!";
      }
    }else{
    // if the form hasn't been submitted, get the data from the db and display the form
    // get the 'id' value from the URL (if it exists), making sure that it is valid (checking that it is numeric/larger than 0)
    if (isset($_GET['invoice_id']) && is_numeric($_GET['invoice_id']) && $_GET['invoice_id'] > 0){
		$id0=mysql_real_escape_string($_GET['invoice_id']);

		//select all data that relates to it...
		$sql=mysql_query("SELECT * FROM invoice WHERE invoice_id='$id0'") or die(mysql_error());
		$row=mysql_fetch_array($sql);
		if($row>0){
			$mreq_id=$row['mreq_id'];
			$studentreg=$row['student_regno'];
			$studentnm=$row['student_name'];
			$program=$row['program'];
			$invenid=$row['inventory_id'];
			$equipmentname=$row['equipment_name'];
			$quantity=$row['quantity'];
			$icost=$row['unit_cost'];
			$tcost=$row['total_cost'];
			$date=$row['date'];
			renderForm($id0, $mreq_id, $studentreg, $studentnm, $program, $invenid, $equipmentname, $quantity, $icost, $tcost, $date, '');
      }else{
        echo "No results!";
      }
    }else{
    // if the 'id' in the URL isn't valid, or if there is no 'id' value, display an error
      echo "Error!";
    }
}
?>
