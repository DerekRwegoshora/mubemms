<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['admin_id'])){
$id=$_SESSION['admin_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
exit();
}
$id0=mysql_real_escape_string($_GET['staff_id']);
$sql="DELETE FROM staff WHERE staff_id='$id0'";
mysql_query($sql);
//$rows=mysql_fetch_assoc($result);
header("location:staff.php");
?>
