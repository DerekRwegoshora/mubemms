<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['admin_id'])){
$id=$_SESSION['admin_id'];
$user=$_SESSION['username'];
}else{
	header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
	exit();
	}
	if(count($_POST)>0){
		$query=mysql_query("SELECT * FROM login WHERE admin_id='".$id."'");
		$row=mysql_fetch_array($query);
		if ($_POST['currentPassword'] == $row["password"] && $_POST['newPassword'] == $_POST["confirmPassword"]) {
			mysql_query("UPDATE login SET password='".$_POST["newPassword"]."' WHERE admin_id='".$id."'");
			$message1="<font color=white>Password changed successfully</font><br/>";
			}else{
			$message="<font color=red>Password is incorrect!</font><br/>";
			}
	}
?>
<!DOCTYPE html>
<html>
<?php include 'includes/header.php'?>
   <link rel="stylesheet" href="../assets/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
   <script>
	   function validatePassword(){
		   var currentPassword, newPassword, confirmPassword, output = true;

		   currentPassword = document.myform.currentPassword;
		   newPassword = document.myform.newPassword;
		   confirmPassword = document.myform.confirmPassword;

			if(!currentPassword.value){
				currentPassword.focus();
				document.getElementById("currentPassword").innerHTML = "required";
				output = false;
			}
			else if(!newPassword.value){
				newPassword.focus();
				document.getElementById("newPassword").innerHTML = "required";
				output = false;
			}
			else if(!confirmPassword.value){
				confirmPassword.focus();
				document.getElementById("confirmPassword").innerHTML = "required";
				output = false;
			}
			if(newPassword.value != confirmPassword.value){
				newPassword.value="";
				confirmPassword.value="";
				newPassword.focus();
				document.getElementById("confirmPassword").innerHTML = "not the same";
				output = false;
			}
			return ouput;

	   }
   </script>
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Account</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-user">&nbsp;</em> Change Password</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
		<div class="panel-body">
						<div class="col-md-12">
						<div align="center" style="width: 100%; height: 100%; background-color: #00BFFF;"><?php echo $message1; ?></div>
						  <div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;"><?php echo $message; ?></div>
							<form name="myform" action="changepass.php" method="post" onSubmit="return validatePassword()" style="margin-top: 3px;">
								<div class="form-group col-md-12">
									<label>Current Password</label>
									<input class="form-control" type="password" name="currentPassword" required/>
								</div>
								<div class="form-group col-md-12">
									<label>New Password</label>
									<input class="form-control" type="password" name="newPassword" minlength="6" title="Please enter at least 6 characters" required/>
								</div>
                <div class="form-group col-md-12">
									<label>Confirm New Password</label>
									<input class="form-control" type="password" name="confirmPassword" minlength="6" title="Please enter at least 6 characters" required/>
								</div>
								<div class="form-group col-md-12">
									<input class="btn btn-primary" name="submit" type="submit" value="Update"/>
								</div>
							</form>
						</div>
					</div>
		</div>
	</div>	<!--/.main-->

    <?php include 'includes/footer.php'?>
   <!-- DataTables  & Plugins -->
   <script src="../assets/tables/datatables/jquery.dataTables.min.js"></script>
   <script src="../assets/tables/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script>
      $(function () {
         $("#example1").DataTable();
      });
   </script>

</body>
</html>
