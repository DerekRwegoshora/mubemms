<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['admin_id'])){
$id=$_SESSION['admin_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
exit();
}
if(isset($_POST['submit'])){
	$name=$_POST['name'];
	$typee=$_POST['type'];
	$nums=$_POST['number'];

	$sql1=mysql_query("SELECT * FROM location WHERE name='$name' AND type='$typee' AND number='$nums'")or die(mysql_error());
	 $result=mysql_num_rows($sql1);
	if($result>0){
	$message="<font color=red>The hostel/venue entered, already exists!</font>";
	 }else{
	$sql=mysql_query("INSERT INTO location(name,type,number)
	VALUES('$name','$typee','$nums')");
	if($sql>0) {
		$message2="<font color=white>Building has been added successfully</font>";
	}else{
	$message1="<font color=red>Failed to add building, please try again!</font>";
	}
  }
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include 'includes/header.php'?>
	<script>
function validateForm()
{

//for alphabet characters only
var str=document.form1.name.value;
 var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
 //comparing user input with the characters one by one
 for(i=0;i<str.length;i++)
 {
 //charAt(i) returns the position of character at specific index(i)
 //indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
 if(valid.indexOf(str.charAt(i))==-1)
 {
 alert("Building Name Cannot Contain Numerical Values");
 document.form1.name.value="";
 document.form1.name.focus();
 return false;
 }}

if(document.form1.name.value=="")
{
alert("Building Name Field is Empty");
return false;
}

//for alphabet characters only
var str=document.form1.type.value;
 var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
 //comparing user input with the characters one by one
 for(i=0;i<str.length;i++)
 {
 //charAt(i) returns the position of character at specific index(i)
 //indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
 if(valid.indexOf(str.charAt(i))==-1)
 {
 alert("Type Cannot Contain Numerical Values");
 document.form1.type.value="";
 document.form1.type.focus();
 return false;
 }}


if(document.form1.type.value=="")
{
alert("Type Field is Empty");
return false;
}

//for alphabet characters only
var str=document.form1.number.value;
 var valid="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
 //comparing user input with the characters one by one
 for(i=0;i<str.length;i++)
 {
 //charAt(i) returns the position of character at specific index(i)
 //indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
 if(valid.indexOf(str.charAt(i))==-1)
 {
 alert("Room Number/Floor Level Cannot Contain Special Characters");
 document.form1.number.value="";
 document.form1.number.focus();
 return false;
 }}


if(document.form1.number.value=="")
{
alert("Number Field is Empty");
return false;
}

}

</script>
</head>
   <link rel="stylesheet" href="../assets/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Buildings & Estates</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-building">&nbsp;</em> Add Building or Estate</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
		    <div class="panel-body">
						<div class="col-md-12">
						<div align="center" style="width: 100%; height: 100%; background-color: #00BFFF;"><?php echo $message2; ?></div>
						<div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;"><?php echo $message;
						echo $message1; ?></div>
							<form name="form1" onsubmit="return validateForm(this);" action="add-estate.php" method="post" style="margin-top: 3px;">
								<div class="form-group col-md-12">
									<label>Building or Estate Name</label>
									<input class="form-control" name="name" type="text" placeholder="Example: Kinjekitile" required id="name" />
								</div>
								<div class="form-group col-md-12">
									<label>Building or Estate Type</label>
									<input class="form-control" name="type" type="text" placeholder="Example: Hostel" required id="type"/>
								</div>
								<div class="form-group col-md-12">
									<label>Room Number/Floor Level</label>
									<input class="form-control" name="number" type="text" placeholder="Example: 5" required id="number" />
								</div>
								<div class="form-group col-md-12">
									<a href="estate.php" class="btn btn-primary" >Cancel</a>
                  <input class="btn btn-primary" name="submit" type="submit" value="Submit"/>
								</div>
              </form>
						</div>
			   </div>
			 </div>
			</div><!--/.main-->

    <?php include 'includes/footer.php'?>
   <!-- DataTables  & Plugins -->
   <script src="../assets/tables/datatables/jquery.dataTables.min.js"></script>
   <script src="../assets/tables/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script>
      $(function () {
         $("#example1").DataTable();
      });
   </script>

</body>
</html>
