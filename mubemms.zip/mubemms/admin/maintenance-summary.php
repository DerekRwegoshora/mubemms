<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['admin_id'])){
$id=$_SESSION['admin_id'];
$user=$_SESSION['username'];
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
exit();
}
$query1=mysql_query("SELECT * FROM mrequest WHERE status='Pending'") or die(mysql_error());
$row1=mysql_num_rows($query1);
//
$query2=mysql_query("SELECT * FROM maintenance_history") or die(mysql_error());
$row2=mysql_num_rows($query2);
//
$query3=mysql_query("SELECT location, COUNT(location) AS most_frequent FROM mrequest WHERE status='Pending' GROUP BY location ORDER BY COUNT(location) DESC LIMIT 1") or die(mysql_error());
$sql3=mysql_fetch_array($query3);
$row3=$sql3['location'];
$row333=$sql3['most_frequent'];
//
$query5=mysql_query("SELECT location, COUNT(location) AS most_frequent FROM maintenance_history GROUP BY location ORDER BY COUNT(location) DESC LIMIT 1") or die(mysql_error());
$sql5=mysql_fetch_array($query5);
$row5=$sql5['location'];
$row555=$sql5['most_frequent'];
//
$query6=mysql_query("SELECT equipment_name, COUNT(equipment_name) AS most_frequent FROM mrequest WHERE status='Pending' GROUP BY equipment_name ORDER BY COUNT(equipment_name) DESC LIMIT 1") or die(mysql_error());
$sql6=mysql_fetch_array($query6);
$row6=$sql6['equipment_name'];
$row666=$sql6['most_frequent'];
//
$query7=mysql_query("SELECT equipment_name, SUM(quantity_used) AS most_used FROM maintenance_history GROUP BY equipment_name ORDER BY SUM(quantity_used) DESC LIMIT 1") or die(mysql_error());
$sql7=mysql_fetch_array($query7);
$row7=$sql7['equipment_name'];
$row777=$sql7['most_used'];
//
$query8=mysql_query("SELECT SUM(quantity_used) AS total_used FROM maintenance_history") or die(mysql_error());
$sql8=mysql_fetch_array($query8);
$row8=$sql8['total_used'];
?>
<!DOCTYPE html>
<html>
<?php include 'includes/header.php'?>
   <link rel="stylesheet" href="../assets/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Maintenance Tasks</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-bar-chart">&nbsp;</em> Maintenance Tasks Summary</h1>
			</div>
		</div><!--/.row-->

    		<div class="panel panel-container">
          <div class="panel-body">
  						<div class="col-md-12">
  							<form role="form">
  								<div class="form-group col-md-6">
  									<label>Total Number of Maintenance Task Requests</label>
  									<input type="text" class="form-control" value="<?php echo $row1; ?>" readonly />
  								</div>
  								<div class="form-group col-md-6">
  									<label>Total Number of Completed Maintenance Tasks</label>
  									<input type="text" class="form-control" value="<?php echo $row2; ?>" readonly />
  								</div>
  								<div class="form-group col-md-6">
  									<label>Location with Most Pending Maintenance Requests</label>
  									<input type="text" class="form-control" value="<?php if($sql3 > 0){
                      echo $row3.""." (".$row333.")";
                    }else{
                      echo "N/A";
                    } ?>" readonly />
  								</div>
                  <div class="form-group col-md-6">
  									<label>Location with Most Completed Maintenance Tasks</label>
  									<input type="text" class="form-control" value="<?php if($sql5 > 0){
                      echo $row5.""." (".$row555.")";
                    }else{
                        echo "N/A";
                      } ?>" readonly />
  								</div>
  								<div class="form-group col-md-6">
  									<label>Most Requested Inventory Item</label>
  									<input type="text" class="form-control" value="<?php if($sql6 > 0){
                      echo $row6.""." (".$row666.")";
                    }else{
                        echo "N/A";
                      } ?>" readonly />
  								</div>
  								<div class="form-group col-md-6">
  									<label>Most Used Inventory Item</label>
  									<input type="text" class="form-control" value="<?php if($sql7 > 0){
                      echo $row7.""." (".$row777.")";
                    }else{
                        echo "N/A";
                      } ?>" readonly />
  								</div>
                  <div class="form-group col-md-12">
  									<label>Total Inventory Items Used (Quantity)</label>
  									<input type="text" class="form-control" value="<?php if($sql8 > 0){
                      echo $row8;
                    }else{
                          echo "0";
                        } ?>" readonly />
  								</div>
                    <br/><br/>
                  <div class="form-group col-md-12">
                    <div class="form-group col-md-6" style="text-align: center;">
                      <h4><u>Analytics</u></h4>
                      <h6>For Locations</h6>
                      <canvas id="bargraph1" height="200"></canvas>
                    </div>
                    <div class="form-group col-md-6" style="text-align: center;">
                      <h4><u>Analytics</u></h4>
                      <h6>For Items</h6>
                      <canvas id="bargraph2" height="200"></canvas>
                    </div>
                  </div>
  							</form>
  						</div>
  					</div>
          </div>
        </div>	<!--/.main-->

    <?php include 'includes/footer.php'?>
        <script src="../assets/js/chart.js"></script>
   <!-- DataTables  & Plugins -->
   <?php  include_once('/../assets/connect_db.php');
    $query33=mysql_query("SELECT location, COUNT(location) AS most_frequent FROM maintenance_history GROUP BY location ORDER BY COUNT(location) DESC LIMIT 5") or die(mysql_error());
    if($query33){
      $chart_data="";
      $location_name = array();
      $frequency = array();
      while($sql33=mysql_fetch_assoc($query33)){
        $location_name[] = $sql33['location'];
        $frequency[] = $sql33['most_frequent'];
      }
    }
    $query44=mysql_query("SELECT equipment_name, SUM(quantity_used) AS most_used FROM maintenance_history GROUP BY equipment_name ORDER BY SUM(quantity_used) DESC LIMIT 5") or die(mysql_error());
    if($query44){
      $chart_data="";
      $equip_name = array();
      $frequency2 = array();
      while($sql44=mysql_fetch_assoc($query44)){
        $equip_name[] = $sql44['equipment_name'];
        $frequency2[] = $sql44['most_used'];
      }
    }
   ?>
   <script type="text/javascript">
      var ctx = document.getElementById("bargraph1").getContext('2d');
         // Bar Chart
         var myChart = new Chart(ctx,{
           type:'bar',
           data:{
            labels: <?php echo json_encode($location_name); ?>,
            datasets: [{
               backgroundColor: [
                 "#5969ff",
                 "#ff407b",
                 "#25d5f2",
                 "#ffc750",
                 "#2ec551"
            ],
          data: <?php echo json_encode($frequency); ?>
        }]
      },
      options:{
        legend:{
          display: false,
          position:'bottom',

          labels:{
            label: 'Location',
            fontColor:'#71748d',
            fontFamily:'Circular Std Book',
            fontSize: 14,
          }
        },
        scales:{
          yAxes: [{
            ticks:{
              beginAtZero: true
            }
          }]
        }
      }
    });
   </script>
   <script type="text/javascript">
      var ctx = document.getElementById("bargraph2").getContext('2d');
         // Bar Chart
         var myChart = new Chart(ctx,{
           type:'bar',
           data:{
            labels: <?php echo json_encode($equip_name); ?>,
            datasets: [{
               backgroundColor: [
                 "#5969ff",
                 "#ff407b",
                 "#25d5f2",
                 "#ffc750",
                 "#2ec551"
            ],
          data: <?php echo json_encode($frequency2); ?>
        }]
      },
      options:{
        legend:{
          display: false,
          position:'bottom',

          labels:{
            label: 'Items',
            fontColor:'#71748d',
            fontFamily:'Circular Std Book',
            fontSize: 14,
          }
        },
        scales:{
          yAxes: [{
            ticks:{
              beginAtZero: true
            }
          }]
        }
      }
    });
   </script>
</body>
</html>
