<?php
error_reporting (1);
$con=mysql_connect('localhost','root','')or die("cannot connect to server");
mysql_select_db('mubemms')or die("cannot connect to database");

?>
