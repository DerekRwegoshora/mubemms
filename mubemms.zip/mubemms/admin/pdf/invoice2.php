<?php
//include connection file
include_once('fpdf/fpdf.php');
include_once("connection.php");

session_start();
if(isset($_GET['invoice_id'])){
$id0=$_GET['invoice_id'];
class PDF extends FPDF
{
// Page header
function Header()
{
// Arial italic 8
$this->SetFont('Arial','B',12);
// Title
$image="C:/xampp/htdocs/mubemms/assets/image/logo1.png";
$dir=$this->Image($image,10,10,18);
$this->Cell(24,10,$dir,0,0,'L');
//
$this->Cell(150,20,'Student Invoice - MU-BEMMS',0,0,'L');
// Line break
$this->Ln(20);
}

// Page footer
function Footer()
{
// Position at 1.5 cm from bottom
$this->SetY(-15);
// Arial italic 8
$this->SetFont('Arial','I',8);
// Page number
$this->Cell(0,6,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

$db = new dbObj();
$connString =  $db->getConnstring();
$display_heading = array('invoice_id'=>'Bill No.', 'mreq_id'=>'Request No.', 'student_regno'=>'Student ID', 'student_name'=>'Name', 'program'=>'Program',
'inventory_id'=>'Item No.', 'equipment_name'=>'Item Name', 'quantity'=>'Quantity', 'unit_cost'=>'Unit Cost', 'total_cost'=>'Total Cost', 'date'=>'Date Issued');

$result = mysqli_query($connString, "SELECT invoice_id,mreq_id,student_regno,student_name,program,inventory_id,equipment_name,quantity,unit_cost,total_cost,date
  FROM invoice WHERE invoice_id='$id0'") or die("database error:". mysqli_error($connString));
$header = mysqli_query($connString, "SHOW columns FROM invoice");
//
$row=mysqli_fetch_assoc($result);
$studentid=$row['student_regno'];
//
$pdf = new PDF('L', 'mm', 'Letter');
//header
$pdf->AddPage();
//footer page
$pdf->AliasNbPages();
$pdf->SetFont('Arial','B',9.5);
foreach($header as $heading) {
$pdf->setFillColor(223, 223, 223);
$pdf->Cell(24,12,$display_heading[$heading['Field']],1,0,'L',TRUE);
}
$pdf->SetFont('Arial','B',8);
foreach($result as $row) {
$pdf->Ln();
foreach($row as $column)
$pdf->Cell(24,12,$column,1,'L');
}
$pdf->Output('student_'.$studentid.'_invoice_mubemms.pdf', 'I');
}
?>
