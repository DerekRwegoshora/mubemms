<?php
	session_start();
	include_once('assets/connect_db.php');
	include_once('assets/PHPMailer/PHPMailerAutoload.php');
	if(isset($_SESSION['username'])){
	$id=$_SESSION['admin_id'];
	$user=$_SESSION['username'];
		}else{
		header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
		exit();
		}

		$id0=mysql_real_escape_string($_GET['mreq_id']);
		//selecting then store as array
		$sql=mysql_query("SELECT * FROM mrequest WHERE mreq_id='$id0'") or die(mysql_error());
		$row=mysql_fetch_array($sql);
		//$idd=$row['mreq_id'];
		$sno=$row['student_regno'];
				$filtersno=substr($sno, -5);
		$sname=$row['student_name'];
		$prg=$row['program'];
		$invenid=$row['inventory_id'];
		$qua=$row['quantity'];
		$ename=$row['equipment_name'];
		//
		$sql2=mysql_query("SELECT cost FROM inventory WHERE inventory_id='$invenid'") or die(mysql_error());
		$row2=mysql_fetch_array($sql2);
		$icost=$row2['cost'];
		$tcost=(($qua)*($icost));
		//query that will take user data and insert into
		//inserting again into the table
			$query=mysql_query("INSERT INTO invoice(mreq_id,student_regno,student_name,program,inventory_id,equipment_name,quantity,unit_cost,total_cost,date) VALUES('$id0','$sno','$sname','$prg','$invenid','$ename','$qua','$icost','$tcost',NOW())") or die(mysql_error());
			if($query > 0) {
				$res=mysql_query("SELECT * FROM student WHERE student_regno='$filtersno'");
			  $r=mysql_fetch_assoc($res);
			  $to=$r['email'];
			  $subject="You have a pending invoice - MU-BEMMS";
			  $message="Please login into your MUBEMMS account, you have a pending bill with no: ".$invenid.", and amount: Tsh.".$tcost;
			  $headers="From : MU-BEMMS";
				mail($to, $subject, $message, $headers);
				//
				$fetch=mysql_query("SELECT * FROM invoice WHERE mreq_id='$id0'");
			  $show=mysql_fetch_assoc($fetch);
				$_SESSION['id']=$show['invoice_id'];
				header("location:invoice.php");
				}else{
					$mess="<font color=red>Failed to generate invoice, please try again!</font>";
				}
	?>
