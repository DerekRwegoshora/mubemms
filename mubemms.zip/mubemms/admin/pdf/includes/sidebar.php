

	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<div class="profile-sidebar">
			<div style="margin-top:12px; margin-left:10px; float:left; clear:float;">
				<img src="../assets/image/logo1.png" class="img-responsive" height="47px" width="50px" alt="admin">
			</div>
			<div class="profile-usertitle">
				<div class="profile-usertitle-name" style="font-size: 12px;"><b><?php echo 'Admin: SSN/'.$id.',';
        echo '<br>'.$user; ?></b></div>
				<div class="profile-usertitle-status"><span class="indicator label-success"></span>Online</div>
			</div>
			<div class="clear"></div>
		</div>

		<ul class="nav menu">
			<li><a href="../index.php"><em class="fa fa-dashboard">&nbsp;</em> Dashboard</a></li>
			<li class="parent "><a data-toggle="collapse" href="#sub-item-4">
				<em class="fa fa-wrench">&nbsp;</em> Maintenance Tasks <span data-toggle="collapse" href="#sub-item-4" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-4">
					<li><a class="" href="../task-information.php">
						<span class="fa fa-wrench">&nbsp;</span> Task Requests
					</a></li>
					<li><a class="" href="../maintenance-history.php">
						<span class="fa fa-wrench">&nbsp;</span> Tasks History
					</a></li>
					<li><a class="" href="../maintenance-summary.php">
						<span class="fa fa-bar-chart">&nbsp;</span> Tasks Summary
					</a></li>
				</ul>
			</li>
			<li class="parent "><a data-toggle="collapse" href="#sub-item-6">
				<em class="fa fa-building">&nbsp;</em> Buildings & Estates <span data-toggle="collapse" href="#sub-item-6" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-6">
					<li><a class="" href="../add-estate.php">
						<span class="fa fa-building">&nbsp;</span> Add Building or Estate
					</a></li>
					<li><a class="" href="../estate.php">
						<span class="fa fa-building">&nbsp;</span> Buildings & Estates
					</a></li>
				</ul>
			</li>
			<li class="parent "><a data-toggle="collapse" href="#sub-item-2">
				<em class="fa fa-file-text">&nbsp;</em> Item Inventory <span data-toggle="collapse" href="#sub-item-2" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-2">
					<li><a class="" href="../add-inventory.php">
						<span class="fa fa-file-text">&nbsp;</span> Add Item
					</a></li>
					<li><a class="" href="../inventory.php">
						<span class="fa fa-file-text">&nbsp;</span> Item Inventory List
					</a></li>
				</ul>
			</li>
			<li><a href="../invoice.php"><em class="fa fa-money">&nbsp;</em> Student Invoices</a></li>
			<li class="parent "><a data-toggle="collapse" href="#sub-item-5">
				<em class="fa fa-users">&nbsp;</em> Students <span data-toggle="collapse" href="#sub-item-5" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-5">
					<li><a class="" href="../add-student.php">
						<span class="fa fa-users">&nbsp;</span> Add Student
					</a></li>
					<li><a class="" href="../student.php">
						<span class="fa fa-users">&nbsp;</span> Student Roster
					</a></li>
				</ul>
			</li>
			<li class="parent "><a data-toggle="collapse" href="#sub-item-1">
				<em class="fa fa-user-secret">&nbsp;</em> Staff <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-1">
					<li><a class="" href="../add-staff.php">
						<span class="fa fa-user-secret">&nbsp;</span> Add Staff
					</a></li>
					<li><a class="" href="../staff.php">
						<span class="fa fa-user-secret">&nbsp;</span> Staff Members
					</a></li>
				</ul>
			</li>
			<li class="parent "><a data-toggle="collapse" href="#sub-item-3">
				<em class="fa fa-user">&nbsp;</em> Account <span data-toggle="collapse" href="#sub-item-3" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-3">
					<li><a class="" href="../profile.php">
						<span class="fa fa-user">&nbsp;</span> My Profile
					</a></li>
					<li><a class="" href="../changepass.php">
						<span class="fa fa-user">&nbsp;</span> Change Password
					</a></li>
				</ul>
			</li>
			<li><a href="assets/logout.php"><em class="fa fa-power-off">&nbsp;</em> Logout</a></li>
		</ul>
	</div><!--/.sidebar-->
