<?php
session_start();
function renderForm($id0, $firstname, $lastname, $program, $contact, $email0, $uname, $pass, $error){
	if(isset($_SESSION['admin_id'])){
		$id=$_SESSION['admin_id'];
		$user=$_SESSION['username'];
	}else{
		header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
		exit();
		}
?>
<!DOCTYPE html>
<html>
<head>
<?php include 'includes/header.php'?>
   <link rel="stylesheet" href="../assets/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
	 <script>
 function validateForm()
 {

 //for alphabet characters only
 var str=document.form1.firstname.value;
 	var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
 	//comparing user input with the characters one by one
 	for(i=0;i<str.length;i++)
 	{
 	//charAt(i) returns the position of character at specific index(i)
 	//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
 	if(valid.indexOf(str.charAt(i))==-1)
 	{
 	alert("First Name Cannot Contain Numerical Values");
 	document.form1.firstname.value="";
 	document.form1.firstname.focus();
 	return false;
 	}}

 if(document.form1.firstname.value=="")
 {
 alert("First Name Field is Empty");
 return false;
 }

 //for alphabet characters only
 var str=document.form1.lastname.value;
 	var valid="abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ";
 	//comparing user input with the characters one by one
 	for(i=0;i<str.length;i++)
 	{
 	//charAt(i) returns the position of character at specific index(i)
 	//indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
 	if(valid.indexOf(str.charAt(i))==-1)
 	{
 	alert("Last Name Cannot Contain Numerical Values");
 	document.form1.lastname.value="";
 	document.form1.lastname.focus();
 	return false;
 	}}


 if(document.form1.lastname.value=="")
 {
 alert("Last Name Field is Empty");
 return false;
 }

 //for alphabet characters only
 var str=document.form1.phonez.value;
  var valid="0123456789";
  //comparing user input with the characters one by one
  for(i=0;i<str.length;i++)
  {
  //charAt(i) returns the position of character at specific index(i)
  //indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
  if(valid.indexOf(str.charAt(i))==-1)
  {
  alert("Contact Cannot Contain Letters");
  document.form1.phonez.value="";
  document.form1.phonez.focus();
  return false;
  }}


 if(document.form1.phonez.value=="")
 {
 alert("Last Name Field is Empty");
 return false;
 }

 }

 </script>
</head>
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Student</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-user-plus">&nbsp;</em> Update Student</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
		    <div class="panel-body">
					<div class="col-md-12">
					 <div align="center" style="width: 100%; height: 100%; background-color: #00BFFF;"><?php echo $message2; ?></div>
						<div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;"><?php echo $message1; ?></div>
						 <?php if ($error!=''){ echo '<div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;">'.$error.'</div>';} ?>
							<form action="update-student.php" method="post" name="form1" onsubmit="return validateForm(this);" style="margin-top: 3px;">
								<input type="hidden" name="student_regno" value="<?php echo $id0; ?>"/>
								<div class="form-group col-md-12">
									<label>First Name</label>
									<input class="form-control" name="firstname" type="text" value="<?php echo $firstname; ?>" id="firstname" />
								</div>
                				<div class="form-group col-md-12">
									<label>Last Name</label>
									<input class="form-control" name="lastname" type="text" id="lastname" value="<?php echo $lastname; ?>" />
								</div>
								<div class="form-group col-md-12">
									<label>Program</label>
									<input class="form-control" name="program" type="text" id="program" value="<?php echo $program; ?>" readonly/>
								</div>
                				<div class="form-group col-md-12">
									<label>Contact</label>
									<input class="form-control" name="phonez" type="text" id="phonez" value="<?php echo $contact; ?>" />
								</div>
								<div class="form-group col-md-12">
									<label>Email</label>
									<input class="form-control"  name="emailz" type="email" id="emailz" value="<?php echo $email0; ?>" />
								</div>
								<div class="form-group col-md-12">
								<div class="form-group col-md-8">
								<div class="form-group col-md-12">
									<label>Username</label>
									<input class="form-control" name="username" type="text" id="username" value="<?php echo $uname; ?>" readonly/>
								</div>
								<div class="form-group col-md-12">
									<label>Password</label>
									<input class="form-control" name="password" type="password" id="password" value="<?php echo $pass; ?>" minlength="6" title="Please enter at least 6 characters" />
								</div>
								</div>
								</div>
								<div class="form-group col-md-12">
									<a href="student.php" class="btn btn-primary" >Cancel</a>
                  <input class="btn btn-primary" name="submit" type="submit" value="Update"/>
								</div>
              </form>
						</div>
			   </div>
			</div>
		</div>	<!--/.main-->

    <?php include 'includes/footer.php'?>
   <!-- DataTables  & Plugins -->
   <script src="../assets/tables/datatables/jquery.dataTables.min.js"></script>
   <script src="../assets/tables/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script>
      $(function () {
         $("#example1").DataTable();
      });
   </script>

</body>
</html>
<?php
  }
  //create the connection
  include_once('/../assets/connect_db.php');

  if (isset($_POST['submit'])){
    // confirm that the 'id' value is a valid integer before getting the form data
    if (is_numeric($_POST['student_regno'])){
      // get form data, making sure it is valid
	  	$id0=$_POST['student_regno'];
		$ftname=$_POST['firstname'];
		$ltname=$_POST['lastname'];
		$progamme=$_POST['program'];
		$phonez=$_POST['phonez'];
		$emailz=$_POST['emailz'];
		$username=$ftname.' '.$ltname;
		$pas=$_POST['password'];

        // check that firstname/lastname fields are both filled in
        if ($ftname=='' || $ltname=='' || $progamme=='' || $phonez=='' || $emailz=='' || $username=='' || $pas==''){
          $error="<font color=red>Please fill in all required fields!</font>";
          renderForm($id0, $firstname, $lastname, $program, $contact, $email0, $uname, $pass, $error);
        }else{
					$query1=mysql_query("UPDATE student SET first_name='$ftname', last_name='$ltname', phone='$phonez', email='$emailz' WHERE student_regno='$id0'") or die(mysql_error());
			$query2=mysql_query("UPDATE login SET first_name='$ftname', last_name='$ltname', email='$emailz', username='$username', password='$pas' WHERE student_regno='$id0'") or die(mysql_error());
			if($query1 > 0 && $query2 > 0) {
				$message2="<font color=white>Student has been updated successfully</font>";
				// once saved, redirect back to the view page
				header("location:student.php");
			}else{
			$message1="<font color=red>Failed to update student, please try again!</font>";
			}
        }
      }else{
        echo "Varr Numerical Error!";
      }
    }else{
    // if the form hasn't been submitted, get the data from the db and display the form
    // get the 'id' value from the URL (if it exists), making sure that it is valid (checking that it is numeric/larger than 0)
    if (isset($_GET['student_regno']) && is_numeric($_GET['student_regno']) && $_GET['student_regno'] > 0){
		$id0=mysql_real_escape_string($_GET['student_regno']);

		//select all data that relates to it...
		$sql=mysql_query("SELECT * FROM student WHERE student_regno='$id0'") or die(mysql_error());
		$row=mysql_fetch_array($sql);
		if($row>0){
			$firstname=$row['first_name'];
			$lastname=$row['last_name'];
			$program=$row['program']." ".$row['year_of_study'];
			$contact=$row['phone'];
			$email0=$row['email'];
			//
			$query=mysql_query("SELECT username,password FROM login WHERE student_regno='$id0'") or die(mysql_error());
			$fetch=mysql_fetch_array($query);
			$uname=$fetch['username'];
			$pass=$fetch['password'];
			renderForm($id0, $firstname, $lastname, $program, $contact, $email0, $uname, $pass, '');
      }else{
        echo "No results!";
      }
    }else{
    // if the 'id' in the URL isn't valid, or if there is no 'id' value, display an error
      echo "Error!";
    }
}
?>
