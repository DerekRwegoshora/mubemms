<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['student_regno'])){
	$id=$_SESSION['student_regno'];
	$fname=$_SESSION['first_name'];
	$lname=$_SESSION['last_name'];
	$user=$_SESSION['username'];
	$yearofstudy=$_SESSION['year_of_study'];
	$startyear=substr($_SESSION['start_year'], -2);
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
exit();
}
if(isset($_POST['submit'])){
	$descr=$_POST['description'];
	$locale=$_POST['location'];
	$equipnamereq=$_POST['equipment_name'];
	$equiptype=$_POST['equip_type'];
	$quantity=$_POST['quantity'];
	//select then insertion
	$sql=mysql_query("SELECT * FROM student WHERE student_regno='$id'") or die(mysql_error());
	$row=mysql_fetch_array($sql);
	$name=$fname.' '.$lname;
	$program=$row['program'].' '.$row['year_of_study'];
	$phone=$row['phone'];
	//select...
	$sql2=mysql_query("SELECT inventory_id,quantity FROM inventory WHERE equipment_name='$equipnamereq'") or die(mysql_error());
	$row2=mysql_fetch_array($sql2);
	$inventid=$row2['inventory_id'];
	$quant=$row2['quantity'];
	if($quant<$quantity){
		$message2="<font color=red>Failed to add request, item quantity available is insufficient!</font>";
	}else{
		//to insert super regno
			$superid=$id.'/T.'.$startyear;
		//to insert into the database tables
		$sql3=mysql_query("INSERT INTO mrequest(student_regno,student_name,program,phone,description,location,inventory_id,equipment_name,equip_type,quantity,date)
		VALUES('$superid','$name','$program','$phone','$descr','$locale','$inventid','$equipnamereq','$equiptype','$quantity',NOW())") or die(mysql_error());
		if($sql3>0){
			$message1="<font color=white>Task Request has been submitted successfuly</font>";
		}else{
			$message="<font color=red>Failed to add request, please try again!</font>";
		}
	}
}
?>
<!DOCTYPE html>
<html>
<head>
<?php include 'includes/header.php'?>
   <link rel="stylesheet" href="../assets/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
	 <script>
 function validateForm()
 {
 //for alphabet characters only
 var str=document.form1.quantity.value;
  var valid="0123456789";
  //comparing user input with the characters one by one
  for(i=0;i<str.length;i++)
  {
  //charAt(i) returns the position of character at specific index(i)
  //indexOf returns the position of the first occurence of a specified value in a string. this method returns -1 if the value to search for never ocurs
  if(valid.indexOf(str.charAt(i))==-1)
  {
  alert("Quantity Cannot Contain Letters");
  document.form1.quantity.value="";
  document.form1.quantity.focus();
  return false;
  }}


 if(document.form1.quantity.value=="")
 {
 alert("Quantity Field is Empty");
 return false;
 }

 }

 </script>
 </head>
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Maintenance Tasks</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-wrench">&nbsp;</em> Request New Maintenance Task</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
			<div class="panel-body">
					<div class="col-md-12">
						 <div align="center" style="width: 100%; height: 100%; background-color: #00BFFF;"><?php echo $message1; ?></div>
						  <div align="center" style="width: 100%; height: 100%; background-color: #FFE5B4;"><?php echo $message; echo $message2; ?></div>
							<form action="new-task.php" method="post" style="margin-top: 3px;" name="form1" onsubmit="return validateForm(this);">
								<div class="form-group col-md-12">
									<label>Description</label>
									<textarea class="form-control" name="description" id="description" maxlength="20" required>Description here</textarea>
								</div>
								<div class="form-group col-md-12">
									<label>Location</label>
									<select class="form-control" name="location" id="location" required>
										<option value="" disabled selected hidden>Choose location</option>
										<?php
											$query=mysql_query("SELECT DISTINCT * FROM location") or die(mysql_error());
											if($query>0){
													while($fetcher=mysql_fetch_array($query)){
														$locname=$fetcher['name'];
														$locroomno=$fetcher['number'];
														$location=$locname.' (Room '.$locroomno.')';
														echo '<option value="'.$location.'">'.$location.'</option>';
													}
												}else{
											?><option value=""disabled selected hidden>No hostels or venues registered...</option><?php
										}
										?>
									</select>
								</div>
								<div class="form-group col-md-12">
									<label>Item Name</label>
									<select class="form-control" name="equipment_name" id="equipment_name" required>
										<option value="" disabled selected hidden>Choose item name</option>
										<?php
											$query2=mysql_query("SELECT DISTINCT equipment_name FROM inventory WHERE status='Available'") or die(mysql_error());
											if($query2>0){
											while($fetchy=mysql_fetch_array($query2)){
												$eqname=$fetchy['equipment_name'];
												echo '<option value="'.$eqname.'">'.$eqname.'</option>';
											}
										}else{
											echo '<option value="" disabled selected hidden>No inventory added/Inavailable</option>';
										}
										?>
									</select>
								</div>
								<div class="form-group col-md-12">
								<div class="form-group col-md-8">
								<div class="form-group col-md-12">
									<label>Item Type</label>
									<select class="form-control" name="equip_type" id="equip_type" required>
										<option value"" disabled selected hidden>Choose item type</option>
										<?php
											$query3=mysql_query("SELECT DISTINCT category FROM inventory WHERE status='Available'") or die(mysql_error());
											if($query3>0){
												while($fetches=mysql_fetch_array($query3)){
													$eqtype=$fetches['category'];
													echo '<option value="'.$eqtype.'">'.$eqtype.'</option>';
												}
											}else{
													echo '<option value="" disabled selected hidden>No inventory added/Inavailable</option>';
											}
										?>
									</select>
								</div>
								<div class="form-group col-md-12">
									<label>Quantity Needed</label>
									<input class="form-control" name="quantity" type="number" required id="quantity" />
								</div>
								</div>
								</div>
								<div class="form-group col-md-12">
									<input class="btn btn-primary" name="submit" type="submit" value="Submit"/>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>	<!--/.main-->

    <?php include 'includes/footer.php'?>
   <!-- DataTables  & Plugins -->
   <script src="../assets/tables/datatables/jquery.dataTables.min.js"></script>
   <script src="../assets/tables/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
   <script src="../assets/tables/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script>
      $(function () {
         $("#example1").DataTable();
      });
   </script>

</body>
</html>
