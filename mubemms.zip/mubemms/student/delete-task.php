<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['student_regno'])){
  $id=$_SESSION['student_regno'];
  $fname=$_SESSION['first_name'];
  $lname=$_SESSION['last_name'];
  $user=$_SESSION['username'];
  $yearofstudy=$_SESSION['year_of_study'];
  $startyear=substr($_SESSION['start_year'], -2);
  $superid=$id.'/T.'.$startyear;
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
exit();
}
$id0=mysql_real_escape_string($_GET['mreq_id']);
$sql="DELETE FROM mrequest WHERE mreq_id='$id0'";
mysql_query($sql);
header("location:task-information.php");
?>
