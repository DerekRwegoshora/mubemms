

	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <div class="profile-sidebar">
			<div style="margin-top:12px; margin-left:10px; float:left; clear:float;">
				<img src="../assets/image/logo1.png" class="img-responsive" height="47px" width="50px" alt="student">
			</div>
			<div class="profile-usertitle">
				<div class="profile-usertitle-name" style="font-size: 12px;"><b><?php echo 'Student: '. $id . '/T.' .$startyear.',';
        echo '<br>'.$user; ?></b></div>
				<div class="profile-usertitle-status"><span class="indicator label-success"></span>Online</div>
			</div>
			<div class="clear"></div>
		</div>

		<ul class="nav menu">
			<li><a href="index.php"><em class="fa fa-dashboard">&nbsp;</em> Dashboard</a></li>
			<li class="parent "><a data-toggle="collapse" href="#sub-item-1">
				<em class="fa fa-wrench">&nbsp;</em> Maintenance Tasks <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-1">
					<li><a class="" href="new-task.php">
						<span class="fa fa-wrench">&nbsp;</span> Request New Task
					</a></li>
					<li><a class="" href="task-information.php">
						<span class="fa fa-wrench">&nbsp;</span> Task Requests
					</a></li>
					<li><a class="" href="maintenance-history.php">
						<span class="fa fa-wrench">&nbsp;</span> Tasks History
					</a></li>
					<li><a class="" href="maintenance-summary.php">
						<span class="fa fa-bar-chart">&nbsp;</span> Tasks Summary
					</a></li>
				</ul>
			</li>
			<li><a href="invoice.php"><em class="fa fa-money">&nbsp;</em> Invoices</a></li>
			<li class="parent "><a data-toggle="collapse" href="#sub-item-2">
				<em class="fa fa-user">&nbsp;</em> Account <span data-toggle="collapse" href="#sub-item-2" class="icon pull-right"><em class="fa fa-plus"></em></span>
				</a>
				<ul class="children collapse" id="sub-item-2">
					<li><a class="" href="profile.php">
						<span class="fa fa-user">&nbsp;</span> My Profile
					</a></li>
					<li><a class="" href="changepass.php">
						<span class="fa fa-user">&nbsp;</span> Change Password
					</a></li>
				</ul>
			</li>
			<li><a href="../assets/logout.php"><em class="fa fa-power-off">&nbsp;</em> Logout</a></li>
		</ul>
	</div><!--/.sidebar-->
