<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['student_regno'])){
$id=$_SESSION['student_regno'];
$fname=$_SESSION['first_name'];
$lname=$_SESSION['last_name'];
$user=$_SESSION['username'];
$yearofstudy=$_SESSION['year_of_study'];
$startyear=substr($_SESSION['start_year'], -2);
$superid=$id.'/T.'.$startyear;
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
exit();
}
?>
<!DOCTYPE html>
<html>
<?php include 'includes/header.php'?>
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Dashboard</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header"><em class="fa fa-tachometer">&nbsp;</em> Dashboard</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
			<div class="row">
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-teal panel-widget border-right">
						<div class="row no-padding"><em class="fa fa-xl fa-wrench color-blue"></em>
							<div class="large"><?php
							$sql=mysql_query("SELECT * FROM mrequest WHERE status='Pending' AND student_regno='$superid'") or die(mysql_error());
							$num=mysql_num_rows($sql);
							echo $num;
							?></div>
							<div class="text-muted">Number of Task Requests</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-blue panel-widget border-right">
						<div class="row no-padding"><em class="fa fa-xl fa-file-text color-blue"></em>
							<div class="large"><?php
							$sql=mysql_query("SELECT DISTINCT * FROM inventory") or die(mysql_error());
							$num=mysql_num_rows($sql);
							echo $num;
							?></div>
							<div class="text-muted">Number of Inventory Items</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-orange panel-widget border-right">
						<div class="row no-padding"><em class="fa fa-xl fa-building color-blue"></em>
							<div class="large"><?php
							$sql=mysql_query("SELECT DISTINCT * FROM location") or die(mysql_error());
							$num=mysql_num_rows($sql);
							echo $num;
							?></div>
							<div class="text-muted">Number of Buildings/Estates</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-red panel-widget ">
						<div class="row no-padding"><em class="fa fa-xl fa-money color-blue"></em>
							<div class="large"><?php
							$sql=mysql_query("SELECT * FROM invoice WHERE student_regno='$superid'") or die(mysql_error());
							$num=mysql_num_rows($sql);
							echo $num;
							?></div>
							<div class="text-muted">Number of Invoices</div>
						</div>
					</div>
				</div>
			</div><!--/.row-->
		</div>

		<div class="row">
			<div class="col-xs-6 col-md-3">
				<div class="panel panel-default">
					<div class="panel-body easypiechart-panel">
						<h6>Pending Maintenance Tasks</h6>
						<?php
							$sql=mysql_query("SELECT * FROM mrequest WHERE status='Pending' AND student_regno='$superid'") or die(mysql_error());
							$count=mysql_num_rows($sql);
							$sql2=mysql_query("SELECT * FROM mrequest WHERE student_regno='$superid'") or die(mysql_error());
							$count2=mysql_num_rows($sql2);
              $math=($count/$count2)*100;
							$percent=round($math,2);
							?>
						<div class="easypiechart" id="easypiechart-blue" data-percent="<?php echo $percent; ?>" ><span class="percent"><?php echo $percent; ?>%</span></div>
					</div>
				</div>
			</div>
			<div class="col-xs-6 col-md-3">
				<div class="panel panel-default">
					<div class="panel-body easypiechart-panel">
						<h6>Completed Maintenance Tasks</h6>
						<?php
							$sql=mysql_query("SELECT * FROM maintenance_history WHERE student_regno='$superid'") or die(mysql_error());
							$num=mysql_num_rows($sql);
							$sql2=mysql_query("SELECT * FROM mrequest WHERE student_regno='$superid'") or die(mysql_error());
							$num2=mysql_num_rows($sql2);
              $math=($num/$num2)*100;
							$percent=round($math,2);
							?>
						<div class="easypiechart" id="easypiechart-teal" data-percent="<?php echo $percent; ?>" ><span class="percent"><?php echo $percent; ?>%</span></div>
					</div>
				</div>
			</div>
		</div><!--/.row-->

	</div>	<!--/.main-->

    <?php include 'includes/footer.php'?>

</body>
</html>
