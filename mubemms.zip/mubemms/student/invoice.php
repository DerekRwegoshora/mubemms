<?php
session_start();
include_once('/../assets/connect_db.php');
if(isset($_SESSION['student_regno'])){
  $id=$_SESSION['student_regno'];
  $fname=$_SESSION['first_name'];
  $lname=$_SESSION['last_name'];
  $user=$_SESSION['username'];
  $yearofstudy=$_SESSION['year_of_study'];
  $startyear=substr($_SESSION['start_year'], -2);
  $superid=$id.'/T.'.$startyear;
}else{
header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/../index.php");
exit();
}
?>
<!DOCTYPE html>
<html>
<?php include 'includes/header.php'?>
   <link rel="stylesheet" href="../assets/tables/datatables-bs4/css/dataTables.bootstrap4.min.css">
   <link rel="stylesheet" href="../assets/css/table.css">
   <script src="../assets/js/sorttable.js"></script>
   <script src="../assets/js/search.js"></script>
<body>

    <?php include 'includes/topbar.php'?>
    <?php include 'includes/sidebar.php'?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Invoices</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12"><?php $quantify=mysql_query("SELECT * FROM invoice WHERE student_regno='$superid'"); $show=mysql_num_rows($quantify);  ?>
				<h1 class="page-header"><em class="fa fa-money">&nbsp;</em> My Invoices (<?php echo $show; ?> bills)</h1>
			</div>
		</div><!--/.row-->

		<div class="panel panel-container">
      <div class="search">
        <div>
          <div>
            <label style="color: grey; font-size: 14px; font-weight: normal; border-color: grey;">Search:&nbsp;</label>
            <input style="height: 38px; width: 200px;" type="text" id="myInput" onkeyup="myFunction('example1')" />
          </div>
        </div>
      </div>
			<div class="example1">
			<?php // connect to the database
        include_once('/../assets/connect_db.php');
       // get results from database
       $result = mysql_query("SELECT * FROM invoice WHERE student_regno='$superid'")or die(mysql_error());
		// display data in table
        echo '<table id="example1" class="table table-hover">';
        echo '<tr class="theader"><th class="border-top-0">Bill No.</th>
          		<th class="border-top-0">Request Form No.</th>
          		<th class="border-top-0">Student ID</th>
          		<th class="border-top-0">Student Name</th>
          		<th class="border-top-0">Program</th>
              <th class="border-top-0">Item No.</th>
          		<th class="border-top-0">Item Name</th>
          		<th class="border-top-0">Item Quantity</th>
              <th class="border-top-0">Unit Cost</th>
          		<th class="border-top-0">Total Cost</th>
          		<th class="border-top-0">Date Issued</th>
          		<th class="sorttable_nosort" id="invisible">Action</th></tr>';
              if(mysql_num_rows($result) < 1){
                ?><tr><td colspan="12" align="center">No data available in table</td></tr><?php
              }else{
        while($row = mysql_fetch_array( $result )) {
			echo "<tr>";
			echo '<td>' . $row['invoice_id'] . '</td>';
			echo '<td>' . $row['mreq_id'] . '</td>';
			echo '<td>' . $row['student_regno'] . '</td>';
			echo '<td>' . $row['student_name'] . '</td>';
			echo '<td>' . $row['program'] . '</td>';
      echo '<td>' . $row['inventory_id'] . '</td>';
			echo '<td>' . $row['equipment_name'] . '</td>';
			echo '<td>' . $row['quantity'] . '</td>';
      echo '<td>' . $row['unit_cost'] . '</td>';
			echo '<td>' . $row['total_cost'] . '</td>';
			echo '<td>' . $row['date'] . '</td>'; ?>
			<td><ul class="pull-right panel-settings" style="border:none">
														<li class="dropdown"><a class="pull-right dropdown-toggle" data-toggle="dropdown" href="#">
															<em class="fa fa-cogs"></em>
														</a>
															<ul class="dropdown-menu dropdown-menu-right">
																<li>
																	<ul class="dropdown-settings">
																		<li><a href="pdf/invoice2.php?invoice_id=<?php echo $row['invoice_id']; ?>">
																			<em class="fa fa-download"></em> download
																		</a></li>
																	</ul>
																</li>
															</ul>
														</li>
													</ul>
                        </td>
                      </tr>
                    <?php
		                }
                  } ?>
                </table>
			</div><!--/.row-->
		</div>
	</div>	<!--/.main-->

    <?php include 'includes/footer.php'?>

</body>
</html>
