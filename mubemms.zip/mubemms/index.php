<?php
include_once('assets/connect_db.php');
if(isset($_POST['submit']) && !empty($_POST)){
	$email=$_POST['email'];
	$password=$_POST['password'];

	$result=mysql_query("SELECT admin_id,student_regno,first_name,last_name,year_of_study,start_year,email,username,password,type FROM login WHERE email='$email' LIMIT 1") or die(mysql_error());
	$fetch=mysql_fetch_array($result);
	$pass=$fetch['password'];

	if($password==$pass){
			$type=$fetch['type'];
			//above we created the variable to carry the "type" of user trying to login, next is validating/determining his/her type
			if($type=='Admin'){
				session_start();
				$_SESSION['admin_id']=$fetch['admin_id'];
				$_SESSION['username']=$fetch['username'];
				header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/admin/index.php");
				//above we created sessions after the type was determined! Same thing happens below, when not admins/important people
			}else{
				session_start();
				$_SESSION['student_regno']=$fetch['student_regno'];
				$_SESSION['first_name']=$fetch['first_name'];
				$_SESSION['last_name']=$fetch['last_name'];
				$_SESSION['username']=$fetch['username'];
				$_SESSION['year_of_study']=$fetch['year_of_study'];
				$_SESSION['start_year']=$fetch['start_year'];
				header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/student/index.php");
			}
		}
		else{ //if the password provided is not correct, meaning the combinations do not match... then generate a report
			$message="<font color=red>Invalid credentials, try again!</font>";
	}
}
echo <<<LOGIN
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login | MU-BEMMS</title>
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/css/datepicker3.css" rel="stylesheet">
	<link href="assets/css/styles.css" rel="stylesheet">
</head>
<body>
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
		  <h4 align="center">Mzumbe University</h4>
			<div class="login-panel panel panel-default" style="padding: 20px; box-shadow: 1px 12px 30px 0px rgba(0,0,0,0.1);">
			  <h5 align="center">Building & Estate Maintenance Management<br>System (MU-BEMMS)</h5>
				<center><img src="assets/image/login_logo.png" height="120px" width="135px"></center>
				<div class="panel-body" style="padding: 5px;" align="center">
				  <div style="width: 100%; height: 100%; background-color: #FFE5B4;">$message</div>
					<form method="post" action="index.php" style="margin-top: 3px;">
						<fieldset>
							<div class="form-group">
								<input class="form-control" type="email" name="email" placeholder="Email" autofocus="" required>
							</div>
							<div class="form-group">
								<input class="form-control" type="password" name="password" placeholder="Password" required>
							</div>
							<center><input style="width: 100%;" type="submit" name="submit" value="Login" class="btn btn-primary"></center>
						</fieldset>
					</form>
				</div>
			</div>
			<center><p style="color: gray; font-size: 12.5px;">Forgot Password?<br>Contact your administrator with your ID in hand</p></center>
		</div><!-- /.col-->
	</div><!-- /.row -->

<script src="assets/js/jquery-1.11.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
LOGIN;
?>
